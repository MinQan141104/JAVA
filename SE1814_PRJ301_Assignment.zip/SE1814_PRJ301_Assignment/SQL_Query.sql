﻿use ASSIGNMENT
-- CREATE FUNCTION 
-- 1. Order
IF OBJECT_ID( 'ViewOrderDetailByOderID','IF') IS NOT NULL
DROP FUNCTION  ViewOrderDetailByOderID
GO
drop function ViewOrderDetailByOderID
-- tìm order detail by order id
CREATE FUNCTION ViewOrderDetailByOderID (@ORDERID int)
returns table
AS 
		RETURN(select od.OrderDetail_ID, p.ProductID, o.OrderID, p.Avatar, p.Name, od.quantity, od.unitPrice, od.afterSalePrice ,od.CreatedAt 
		from [Order] o, OrderDetail od, Product p 
		where o.OrderID = od.OrderID and od.ProductID = p.ProductID and o.OrderID = @ORDERID)

GO
select * from dbo.ViewOrderDetailByOderID (3)
go
drop function ViewOrderByOderID
go

--- tra cứu hóa đơn
CREATE FUNCTION ViewOrderByOderID (@ORDERID int)
returns table
AS 
		RETURN(select o.OrderID, o.userID, o.fullName, o.phoneNumber, o.email, o.Street, o.District, o.City, p.PaymentName, s.methodName, o.totalPrice, o.createdAt, o.order_status
				from [Order] o, ShippingMethod s, PaymentMethod p
				where   o.PaymentMethodID = p.PaymentMethodID and o.ShippingMethodID = s.ShippingMethodID and o.OrderID = @ORDERID)
go

select * from dbo.[ViewOrderByOderID] (2)


GO

CREATE FUNCTION TOTAL_QUANTITY_PRODUCT()
RETURNS table
	as
		return
		(
		select sum(p.Stock) as 'Total Quantity of Products' 
		from product p		
		)

go

SELECT * FROM [dbo].[TOTAL_QUANTITY_PRODUCT] ()
go

CREATE FUNCTION TOTAL_QUANTITY_ORDER()
RETURNS table
	as
		return
		(
		select count(o.OrderID) as 'The Number Of Orders' 
		from [Order] o
		)

go
select * from dbo.TOTAL_QUANTITY_ORDER()
go
CREATE FUNCTION REVENUE()
RETURNS table
	as
		return
		(
		select sum(o.totalPrice) as 'Revenue'
		from [Order] o
		where o.order_status = 'Completed'

		)
GO
select * from dbo.REVENUE()
go
CREATE FUNCTION NUMBER_OF_ACCOUNTS()
RETURNS table
	as
		return
		(
		select count(U.userID) as 'Total Accounts'
		from [User] U 
		)
go

select*from dbo.NUMBER_OF_ACCOUNTS()
go

go
CREATE FUNCTION TOTAL_ORDER_COMPLETED()
RETURNS TABLE
	AS
		RETURN(
				SELECT COUNT(o.OrderID) as 'Total Order Completed '
				FROM [ORDER] O
				WHERE O.order_status = 'Completed'		
		)
go
select*from dbo.TOTAL_ORDER_COMPLETED()

go

-- CREATE VIEW
CREATE VIEW ORDER_TABLE
AS
select o.OrderID, o.userID, o.fullName, o.phoneNumber, o.email, o.Street, u=o.District, o.City, p.PaymentName, s.methodName, o.totalPrice, o.createdAt, o.order_status
from [Order] o, ShippingMethod s, PaymentMethod p 
where o.PaymentMethodID = p.PaymentMethodID and o.ShippingMethodID = s.ShippingMethodID 

go


-- TRIGGER

-- Cập nhật số lượng của sản phẩm khi tạo hóa đơn chi tiết

CREATE TRIGGER trg_UpdateQuantityProduct
ON OrderDetail
	After INSERT
		AS BEGIN
				-- lấy thông tin của insert
				DECLARE @PRODUCT_ID INT
				DECLARE @QUANTITY INT
				SELECT @PRODUCT_ID =i.ProductID, @QUANTITY = i.quantity FROM inserted i 
				-- cập nhật số lượng sản phẩm
				UPDATE Product   
				SET Stock = Stock - @QUANTITY
				WHERE ProductID = @PRODUCT_ID

			END
go


-- Cập nhật tổng tiền trong hóa đơn

CREATE TRIGGER trig_TotalPriceOnOrder 
ON OrderDetail
AFTER INSERT
	AS 
	BEGIN
			DECLARE @SubTotal float = 0
			DECLARE @OrderId int = 0
			DECLARE @TOTAL float = 0
			DECLARE @DiscountAmount float = 0
			-- lấy ra order id
         	SELECT  @OrderId = i.OrderID  FROM inserted i
				
			-- tính tổng tiền trên 1 hóa đơn chi tiết
			SELECT @SubTotal =SUM(quantity * afterSalePrice)
			FROM OrderDetail
			WHERE OrderID = @OrderId

			
			-- tổng tiền trên 1 hóa đơn 
			
			SELECT @DiscountAmount = ISNULL(discountAmount, 0)
			FROM [Order] 
			LEFT JOIN Order_Discount  ON OrderID = Order_ID
			LEFT JOIN DiscountCode ON Discount_ID = discountid
			WHERE OrderID = @OrderId

			SET @TOTAL = @SubTotal - @DiscountAmount
		
			UPDATE [order] 
			SET totalPrice =  @TOTAL
			WHERE OrderID = @OrderId
			
	END
GO

CREATE TRIGGER Trig_UpdateLimitOfDiscountCode
ON Order_Discount
AFTER INSERT
	AS BEGIN
		DECLARE @Limit int = 0
		DECLARE @Limit_Used int = 0
		DECLARE @Limit_After int = 0
		DECLARE @DisCountId float = 0
		-- lấy ra discount id, số lần sử dụng code
		SELECT @DisCountId =  Discount_ID, @Limit_Used = number_Use  FROM inserted

		-- lấy ra số lần sử dụng ban đầu
		SELECT @Limit= usedLimit FROM DiscountCode WHERE  discountid =@DisCountId

		-- cập nhật số lần sử dụng
		SET @Limit_After = @Limit - @Limit_Used
		UPDATE DiscountCode
		SET usedLimit =@Limit_After
		WHERE discountid = @DisCountId
	END
GO