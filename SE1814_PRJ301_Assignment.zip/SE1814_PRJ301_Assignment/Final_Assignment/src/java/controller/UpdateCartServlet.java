/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CartDTO;
import model.ItemDTO;
import model.ProductDAO;
import model.ProductDTO;

/**
 *
 * @author Luu Minh Quan
 */
@WebServlet(name = "UpdateCartServlet", urlPatterns = {"/UpdateCartServlet"})
public class UpdateCartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateCartServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UpdateCartServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
        HttpSession session = request.getSession();
        String id = request.getParameter("id");
        String num = request.getParameter("num");
        String size_raw = request.getParameter("size");

        CartDTO cart = (CartDTO) session.getAttribute("CART");
        try {
            int a = Integer.parseInt(num);
            int id_int = Integer.parseInt(id);
            float size = 0;

            if (size_raw != null && !size_raw.isEmpty()) {
                try {
                    size = Float.parseFloat(size_raw);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid size format: " + size_raw);
                    size = 0;
                }
            }

            if ((a == -1) && (cart.getQuantityById(id_int) <= 1)) {
                cart.removeItem(id_int);
            } else if (a == 1 && (cart.getQuantityById(id_int) >= 10)) {
                request.setAttribute("err", "You cannot add more than 10 items of this product.");
            } else if (a == 1 || a == -1) {
                cart.updateQuantity(id_int, a);
            } else {
                ProductDAO dao = new ProductDAO();
                ProductDTO p = dao.getProductbyId(id);
                double price = p.getPrice();
                ItemDTO item = new ItemDTO(p, a, price, size);
                cart.addItem(item);

            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format: " + num);
        }

        session.setAttribute("CART", cart);
        session.setAttribute("size", String.valueOf(cart.getSize()));
        request.getRequestDispatcher("shopping-cart.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
