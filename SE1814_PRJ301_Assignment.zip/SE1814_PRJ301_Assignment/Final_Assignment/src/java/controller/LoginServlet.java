/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.ProductDAO;
import model.ProductDTO;
import model.ProductIMG;
import model.UserDAO;
import model.UserDTO;

/**
 *
 * @author Luu Minh Quan
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String u = request.getParameter("usernameOrEmail");
        String p = request.getParameter("pass");
//        String role = request.getParameter("role");
        UserDAO us = new UserDAO();
        ProductDAO dao = new ProductDAO();
        String url = "index.jsp";
        String ms = "";
        try {
            UserDTO tmp = us.checkLogin(u, p);
            List<ProductDTO> ls = dao.getRelatedProductList();
            List<ProductDTO> menList = dao.getTopMenList();
            List<ProductDTO> womenList = dao.getTopWomenList();
            List<ProductDTO> list = dao.getProductList();
            List<ProductDTO> ls1 = dao.getKidList();
            if (tmp != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", tmp);
                List<ProductDTO> listWishlist = dao.getAllProductListWish(tmp.getUserId());
                session.setAttribute("sizeWishlist", String.valueOf(listWishlist.size()));
//                session.setAttribute("imgList", ls);  
                session.setAttribute("menList", menList);
                session.setAttribute("womenList", womenList);
                session.setAttribute("productList", list);
                session.setAttribute("RelatedList", ls);
                session.setAttribute("kidList", ls1);
                if (tmp.isuRole()) {
                    response.sendRedirect("adminHome.jsp");
                } else {
                    response.sendRedirect(url);
                }
            } else {
                ms = "UserId or Password was wrong.Please enter again !!!";
                request.setAttribute("err", ms);
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (Exception e) {
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
