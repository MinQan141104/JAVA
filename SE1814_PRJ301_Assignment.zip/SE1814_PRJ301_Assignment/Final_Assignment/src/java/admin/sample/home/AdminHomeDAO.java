/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.home;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import sample.utils.DBUtils;

/**
 *
 * @author DELL
 */
public class AdminHomeDAO {
    public static final String TOTAL_QUANTITY_OF_PRODUCTS ="SELECT * FROM [dbo].[TOTAL_QUANTITY_PRODUCT] ()";
    public static final String THE_NUMBER_OF_ORDERS ="select * from dbo.TOTAL_QUANTITY_ORDER()";
    public static final String REVENUE ="select * from dbo.REVENUE()";
    public static final String TOTAL_ACCOUNTS = "select*from dbo.NUMBER_OF_ACCOUNTS()";
    public static final String TOTAL_ORDER_COMPLETED ="select*from dbo.TOTAL_ORDER_COMPLETED()";
    public int getTotalQuantityOfProducts() throws SQLException{
        int i =0;
        Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if(conn!=null){
                ps = conn.prepareStatement(TOTAL_QUANTITY_OF_PRODUCTS);
                rs = ps.executeQuery();
                if(rs.next()){
                    i = rs.getInt(1);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {}
        finally{
            if(rs!=null){
                rs.close();
            }
            if(ps!=null){
                ps.close();
            }
            if(conn!=null){
                conn.close();
            }
        } 
        return i;
    }
    
     public int getTheNumberOfOrders() throws SQLException{
        int i =0;
        Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if(conn!=null){
                ps = conn.prepareStatement(THE_NUMBER_OF_ORDERS);
                rs = ps.executeQuery();
                if(rs.next()){
                    i = rs.getInt(1);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {}
        finally{
            if(rs!=null){
                rs.close();
            }
            if(ps!=null){
                ps.close();
            }
            if(conn!=null){
                conn.close();
            }
        } 
        return i;
    }
      public int getTheNumberOfOrders_Completed() throws SQLException{
        int i =0;
        Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if(conn!=null){
                ps = conn.prepareStatement(TOTAL_ORDER_COMPLETED);
                rs = ps.executeQuery();
                if(rs.next()){
                    i = rs.getInt(1);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {}
        finally{
            if(rs!=null){
                rs.close();
            }
            if(ps!=null){
                ps.close();
            }
            if(conn!=null){
                conn.close();
            }
        } 
        return i;
    }
       public int getTheNumberOfAccounts() throws SQLException{
        int i =0;
        Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if(conn!=null){
                ps = conn.prepareStatement(TOTAL_ACCOUNTS);
                rs = ps.executeQuery();
                if(rs.next()){
                    i = rs.getInt(1);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {}
        finally{
            if(rs!=null){
                rs.close();
            }
            if(ps!=null){
                ps.close();
            }
            if(conn!=null){
                conn.close();
            }
        } 
        return i;
    }
     
       public float getRevenue() throws SQLException{
        float i =0;
        Connection conn =null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            conn = DBUtils.getConnection();
            if(conn!=null){
                ps = conn.prepareStatement(REVENUE);
                rs = ps.executeQuery();
                if(rs.next()){
                    i = rs.getFloat(1);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {}
        finally{
            if(rs!=null){
                rs.close();
            }
            if(ps!=null){
                ps.close();
            }
            if(conn!=null){
                conn.close();
            }
        } 
        return i;
    }
       
       
       
    public static void main(String[] args) throws SQLException {
        AdminHomeDAO d = new AdminHomeDAO();
        float i = d.getRevenue();
        System.out.println(i);
    }
    
}
