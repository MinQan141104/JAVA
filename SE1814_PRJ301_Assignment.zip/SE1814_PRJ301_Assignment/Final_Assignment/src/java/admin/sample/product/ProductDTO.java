/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.product;


/**
 *
 * @author Layze
 */
public class ProductDTO {
    private int productID;
    private int brandID;
    private int userObjectID;
    private String detail;
    private boolean hot;
    private String name;
    private String avatar;
    private double price;
    private String color;
    private float size;
    private int stock;
    private float sale;
    private boolean productStatus;

    public ProductDTO(int productID, int brandID, int userObjectID, String detail, boolean hot, String name, String avatar, double price, String color, float size, int stock, float sale, boolean productStatus) {
        this.productID = productID;
        this.brandID = brandID;
        this.userObjectID = userObjectID;
        this.detail = detail;
        this.hot = hot;
        this.name = name;
        this.avatar = avatar;
        this.price = price;
        this.color = color;
        this.size = size;
        this.stock = stock;
        this.sale = sale;
        this.productStatus = productStatus;
    }

    public ProductDTO(int productID, int brandID, int userObjectID, String detail, String name, String avatar, double price, String color, float size, int stock, float sale) {
        this.productID = productID;
        this.brandID = brandID;
        this.userObjectID = userObjectID;
        this.detail = detail;
        this.name = name;
        this.avatar = avatar;
        this.price = price;
        this.color = color;
        this.size = size;
        this.stock = stock;
        this.sale = sale;
    }

    public ProductDTO(int brandID, int userObjectID, String detail, String name, String avatar, double price, String color, float size, int stock, float sale) {
        this.brandID = brandID;
        this.userObjectID = userObjectID;
        this.detail = detail;
        this.name = name;
        this.avatar = avatar;
        this.price = price;
        this.color = color;
        this.size = size;
        this.stock = stock;
        this.sale = sale;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getBrandID() {
        return brandID;
    }

    public void setBrandID(int brandID) {
        this.brandID = brandID;
    }

    public int getUserObjectID() {
        return userObjectID;
    }

    public void setUserObjectID(int userObjectID) {
        this.userObjectID = userObjectID;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public boolean isHot() {
        return hot;
    }

    public void setHot(boolean hot) {
        this.hot = hot;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public float getSale() {
        return sale;
    }

    public void setSale(float sale) {
        this.sale = sale;
    }

    public boolean isProductStatus() {
        return productStatus;
    }

    public void setProductStatus(boolean productStatus) {
        this.productStatus = productStatus;
    }
    
    
}
