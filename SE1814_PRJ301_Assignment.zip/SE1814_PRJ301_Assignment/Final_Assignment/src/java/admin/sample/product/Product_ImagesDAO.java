/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

/**
 *
 * @author Layze
 */
public class Product_ImagesDAO {

    private static final String INSERT_IMAGE_SQL = "INSERT INTO Product_Images (ProductID, path) VALUES (?, ?)";
    private static final String DELETE_IMAGE_SQL = "DELETE FROM Product_Images WHERE id = ?";
    private static final String UPDATE_IMAGE_SQL = "UPDATE Product_Images SET path = ? WHERE id = ?";
    private static final String SELECT_IMAGE_BY_ID_SQL = "SELECT path FROM Product_Images WHERE ProductID = ?";
    
    public void addProductImage(int productId, String image) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(INSERT_IMAGE_SQL);
            stmt.setInt(1, productId);
            stmt.setString(2, image);
            stmt.executeUpdate();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    public void updateProductImage(int id, String image) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(UPDATE_IMAGE_SQL);
            stmt.setString(1, image);
            stmt.setInt(2, id);
            stmt.executeUpdate();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    public void deleteProductImage(int imageId) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(DELETE_IMAGE_SQL);
            stmt.setInt(1, imageId);
            stmt.executeUpdate();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    public List<String> getProductImageById(int productId) throws SQLException, ClassNotFoundException {
        List<String> images = new ArrayList();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(SELECT_IMAGE_BY_ID_SQL);
            stmt.setInt(1, productId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                String image = rs.getString("path");
                images.add(image);
            }
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return images;
    }
}
