/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

/**
 *
 * @author Layze
 */
public class ProductDAO {

    public List<ProductDTO> getAllProducts() throws SQLException, ClassNotFoundException {
        List<ProductDTO> productList = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBUtils.getConnection();
            String sql = "SELECT * FROM Product";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                int productId = rs.getInt("ProductID");
                int brandId = rs.getInt("BrandID");
                int userObjectId = rs.getInt("userObjectID");
                String detail = rs.getString("Detail");
                boolean hot = rs.getBoolean("Hot");
                String name = rs.getString("Name");
                String avatar = rs.getString("Avatar");
                double price = rs.getDouble("Price");
                String color = rs.getString("Color");
                float size = rs.getFloat("Size");
                int stock = rs.getInt("Stock");
                float sale = rs.getFloat("Sale");
                boolean productStatus = rs.getBoolean("Product_Status");

                ProductDTO product = new ProductDTO(productId, brandId, userObjectId, detail, hot, name, avatar, price, color, size, stock, sale, productStatus);
                productList.add(product);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return productList;
    }

    public void toggleProductStatus(int productId) throws SQLException, ClassNotFoundException {
        String selectSql = "SELECT Product_Status FROM Product WHERE ProductID = ?";
        String updateSql = "UPDATE Product SET Product_Status = ? WHERE ProductID = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(selectSql);
            stmt.setInt(1, productId);
            rs = stmt.executeQuery();

            boolean currentStatus = false;
            if (rs.next()) {
                currentStatus = rs.getBoolean("Product_Status");
            }

            boolean newStatus = !currentStatus;

            stmt = conn.prepareStatement(updateSql);
            stmt.setBoolean(1, newStatus);
            stmt.setInt(2, productId);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new SQLException("Failed to update product status");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void toggleFlashSaleStatus(int productId) throws SQLException, ClassNotFoundException {
        String selectSql = "SELECT Hot FROM Product WHERE ProductID = ?";
        String updateSql = "UPDATE Product SET Hot = ? WHERE ProductID = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(selectSql);
            stmt.setInt(1, productId);
            rs = stmt.executeQuery();

            boolean currentStatus = false;
            if (rs.next()) {
                currentStatus = rs.getBoolean("Hot");
            }

            boolean newStatus = !currentStatus;

            stmt = conn.prepareStatement(updateSql);
            stmt.setBoolean(1, newStatus);
            stmt.setInt(2, productId);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new SQLException("Failed to update flash sale status");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public int updateProduct(ProductDTO product) throws SQLException, ClassNotFoundException {
        
        Connection con = null;
        PreparedStatement ps = null;
       
        int rowsUpdated = 0;

        try {
            con = DBUtils.getConnection();
            String sql = "UPDATE Product SET BrandID=?, userObjectID=?, Detail=?, Name=?, Avatar=?, Price=?, Color=?, Size=?, Stock=?, Sale=? WHERE ProductID=?";
            ps = con.prepareStatement(sql);

            ps.setInt(1, product.getBrandID());
            ps.setInt(2, product.getUserObjectID());
            ps.setString(3, product.getDetail());
            ps.setString(4, product.getName());
            ps.setString(5, product.getAvatar());
            ps.setDouble(6, product.getPrice());
            ps.setString(7, product.getColor());
            ps.setFloat(8, product.getSize());
            ps.setInt(9, product.getStock());
            ps.setFloat(10, product.getSale());
            ps.setInt(11, product.getProductID());

            rowsUpdated = ps.executeUpdate();

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
        return rowsUpdated;
    }

    public ProductDTO getProductById(int productId) throws SQLException, ClassNotFoundException {
        String selectSql = "SELECT * FROM Product WHERE ProductID = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(selectSql);
            stmt.setInt(1, productId);
            rs = stmt.executeQuery();

            if (rs.next()) {
                return new ProductDTO(
                        rs.getInt("ProductID"),
                        rs.getInt("BrandID"),
                        rs.getInt("userObjectID"),
                        rs.getString("Detail"),
                        rs.getString("Name"),
                        rs.getString("Avatar"),
                        rs.getDouble("Price"),
                        rs.getString("Color"),
                        rs.getFloat("Size"),
                        rs.getInt("Stock"),
                        rs.getFloat("Sale")
                );
            }

            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public int removeProduct(int productId) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        int rowsDeleted = 0;

        try {
            con = DBUtils.getConnection();
            con.setAutoCommit(false);

            String deleteImagesSql = "DELETE FROM Product_Images WHERE ProductID = ?";
            ps = con.prepareStatement(deleteImagesSql);
            ps.setInt(1, productId);
            ps.executeUpdate();
            ps.close();

            String deleteProductSql = "DELETE FROM Product WHERE ProductID = ?";
            ps = con.prepareStatement(deleteProductSql);
            ps.setInt(1, productId);

            rowsDeleted = ps.executeUpdate();

            con.commit(); 
        } catch (SQLException e) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException rollbackEx) {
                    rollbackEx.printStackTrace();
                }
            }
            throw e; 
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.setAutoCommit(true); 
                con.close();
            }
        }

        return rowsDeleted;
    }

    public int addProduct(ProductDTO product) throws SQLException, ClassNotFoundException {
        int productId = -1;
        PreparedStatement ps = null;
        ResultSet generatedKeys = null;
        Connection con = null;
        String sql = "INSERT INTO Product (brandID, userObjectID, detail, name, avatar, price, color, size, stock, sale) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            con = DBUtils.getConnection();
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, product.getBrandID());
            ps.setInt(2, product.getUserObjectID());
            ps.setString(3, product.getDetail());
            ps.setString(4, product.getName());
            ps.setString(5, product.getAvatar());
            ps.setDouble(6, product.getPrice());
            ps.setString(7, product.getColor());
            ps.setFloat(8, product.getSize());
            ps.setInt(9, product.getStock());
            ps.setFloat(10, product.getSale());

            int rowsInserted = ps.executeUpdate();

            if (rowsInserted > 0) {
                generatedKeys = ps.getGeneratedKeys();
                if (generatedKeys.next()) {
                    productId = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating product failed, no ID obtained.");
                }
            }
        } finally {

            if (generatedKeys != null) {
                try {
                    generatedKeys.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return productId;
    }
    
    public List<ProductDTO> searchProductsByName(String name) throws SQLException, ClassNotFoundException {
        List<ProductDTO> products = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBUtils.getConnection();
            String sql = "SELECT * FROM Product WHERE Name LIKE ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + name + "%");
            rs = ps.executeQuery();

            while (rs.next()) {
            int productId = rs.getInt("ProductID");
                int brandId = rs.getInt("BrandID");
                int userObjectId = rs.getInt("userObjectID");
                String detail = rs.getString("Detail");
                boolean hot = rs.getBoolean("Hot");
                String productName = rs.getString("Name");
                String avatar = rs.getString("Avatar");
                double price = rs.getDouble("Price");
                String color = rs.getString("Color");
                float size = rs.getFloat("Size");
                int stock = rs.getInt("Stock");
                float sale = rs.getFloat("Sale");
                boolean productStatus = rs.getBoolean("Product_Status");

                ProductDTO product = new ProductDTO(productId, brandId, userObjectId, detail, hot, productName, avatar, price, color, size, stock, sale, productStatus);
                products.add(product);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return products;
    }
}
