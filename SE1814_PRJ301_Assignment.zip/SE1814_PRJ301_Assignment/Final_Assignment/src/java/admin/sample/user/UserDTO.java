/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.user;

/**
 *
 * @author Layze
 */
import java.util.Date;

public class UserDTO {
    private int userId;
    private String fullName;
    private String userName;
    private String userPass;
    private String phoneNumber;
    private String Sex;
    private String email;
    private Date birth;
    private String Street;
    private String District;
    private String City;
    private boolean isActive;
    private boolean userRole;
    private Date createdAt;

    public UserDTO() {
    }

    public UserDTO(int userId, String fullName, String userName, String userPass, String phoneNumber, String Sex, String email, Date birth, String Street, String District, String City, boolean isActive, boolean userRole, Date createdAt) {
        this.userId = userId;
        this.fullName = fullName;
        this.userName = userName;
        this.userPass = userPass;
        this.phoneNumber = phoneNumber;
        this.Sex = Sex;
        this.email = email;
        this.birth = birth;
        this.Street = Street;
        this.District = District;
        this.City = City;
        this.isActive = isActive;
        this.userRole = userRole;
        this.createdAt = createdAt;
    }

    public UserDTO(int userId, String fullName, String userName, String userPass, String phoneNumber, String Sex, String email, Date birth, String Street, String District, String City, boolean userRole) {
        this.userId = userId;
        this.fullName = fullName;
        this.userName = userName;
        this.userPass = userPass;
        this.phoneNumber = phoneNumber;
        this.Sex = Sex;
        this.email = email;
        this.birth = birth;
        this.Street = Street;
        this.District = District;
        this.City = City;
        this.userRole = userRole;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getSex() {
        return Sex;
    }

    public void setSex(String Sex) {
        this.Sex = Sex;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public String getStreet() {
        return Street;
    }

    public void setStreet(String Street) {
        this.Street = Street;
    }

    public String getDistrict() {
        return District;
    }

    public void setDistrict(String District) {
        this.District = District;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }



    public boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public boolean isUserRole() {
        return userRole;
    }

    public void setUserRole(boolean userRole) {
        this.userRole = userRole;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

}


