/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.user;

/**
 *
 * @author Layze
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

public class UserDAO {

    private static final String INSERT = "INSERT INTO [User] (fullName, userName, userPass, phoneNumber, Sex, email, birth, Street, District, City, isActive, userRole) "
            + "                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

    public List<UserDTO> getAllUser() throws SQLException, ClassNotFoundException {
        List<UserDTO> userList = new ArrayList<>();
        String sql = "SELECT * FROM [User]";

        try (Connection conn = DBUtils.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int userId = rs.getInt("userID");
                String fullName = rs.getString("fullName");
                String userName = rs.getString("userName");
                String userPass = rs.getString("userPass");
                String phoneNumber = rs.getString("phoneNumber");
                String Sex = rs.getString("Sex");
                String email = rs.getString("email");
                Date birth = rs.getDate("birth");
                String Street = rs.getString("Street");
                String District = rs.getString("District");
                String City = rs.getString("City");
                boolean isActive = rs.getBoolean("isActive");
                boolean userRole = rs.getBoolean("userRole");
                Date createdAt = rs.getDate("createdAt");

                UserDTO user = new UserDTO(userId, fullName, userName, userPass, phoneNumber, Sex, email, birth, Street, District, City, isActive, userRole, createdAt);
                userList.add(user);
            }
        }
        return userList;
    }

    public void toggleUserStatus(int userId) throws SQLException, ClassNotFoundException {
        String selectSql = "SELECT isActive FROM [User] WHERE userID = ?";
        String updateSql = "UPDATE [User] SET isActive = ? WHERE userID = ?";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(selectSql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();

            boolean currentStatus = false;
            if (rs.next()) {
                currentStatus = rs.getBoolean("isActive");
            }

            boolean newStatus = !currentStatus;

            stmt = conn.prepareStatement(updateSql);
            stmt.setBoolean(1, newStatus);
            stmt.setInt(2, userId);

            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new SQLException("Failed to update user status");
            }

        } catch (SQLException e) {

            e.printStackTrace();
            throw e;
        } finally {

            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void createUser(String fullName, String userName, String userPass, String Sex, Date birth,
            String phoneNumber, String email, String Street, String District, String City, 
            boolean isActive, int userRole)
            throws SQLException, ClassNotFoundException {

        String sql = "INSERT INTO [User] (fullName, userName, userPass, Sex, birth, phoneNumber, email, Street, District, City, isActive, userRole) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtils.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, fullName);
            stmt.setString(2, userName);
            stmt.setString(3, userPass);
            stmt.setString(4, Sex);
            stmt.setDate(5, birth);
            stmt.setString(6, phoneNumber);
            stmt.setString(7, email);
            stmt.setString(8, Street);
            stmt.setString(9, District);
            stmt.setString(10, City);
            stmt.setBoolean(11, isActive);
            stmt.setInt(12, userRole);

            int rowsInserted = stmt.executeUpdate();

            if (rowsInserted == 0) {
                throw new SQLException("Creating user failed, no rows affected.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    public boolean isUserNameExists(String userName) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM [User] WHERE userName = ?";
        try (Connection conn = DBUtils.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, userName);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0;
                }
            }
        }
        return false;
    }

    public void removeUser(int userId) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM [User] WHERE userID = ?";
        try (Connection conn = DBUtils.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);

            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted == 0) {
                throw new SQLException("User not found for userID: " + userId);
            }
        }
    }

    public int updateUser(int userId, String fullName, String userName, String userPass, String Sex, Date birthDate, String phoneNumber, String email, String Street, String District, String City, int userRole)
            throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;

        try {
            con = DBUtils.getConnection();
            String sql = "UPDATE [User] SET fullName=?, userName=?, userPass=?, Sex=?, birth=?, phoneNumber=?, email=?, Street=?, District=?, City=?, userRole=? WHERE userID=?";
            ps = con.prepareStatement(sql);

            UserDTO currentUser = getUserById(userId); 

            if (fullName == null || fullName.isEmpty()) {
                ps.setString(1, currentUser.getFullName());
            } else {
                ps.setString(1, fullName);
            }

            if (userName == null || userName.isEmpty()) {
                ps.setString(2, currentUser.getUserName());
            } else {
                ps.setString(2, userName);
            }

            if (userPass == null || userPass.isEmpty()) {
                ps.setString(3, currentUser.getUserPass());
            } else {
                ps.setString(3, userPass);
            }

            ps.setString(4, Sex);

            if (birthDate == null) {
                ps.setDate(5, (Date) currentUser.getBirth());
            } else {
                ps.setDate(5, birthDate);
            }

            if (phoneNumber == null || phoneNumber.isEmpty()) {
                ps.setString(6, currentUser.getPhoneNumber());
            } else {
                ps.setString(6, phoneNumber);
            }

            if (email == null || email.isEmpty()) {
                ps.setString(7, currentUser.getEmail());
            } else {
                ps.setString(7, email);
            }

            if (Street == null || Street.isEmpty()) {
                ps.setString(8, currentUser.getStreet());
            } else {
                ps.setString(8, Street);
            }
            
            if (District == null || District.isEmpty()) {
                ps.setString(9, currentUser.getDistrict());
            } else {
                ps.setString(9, District);
            }
            
            if (City == null || City.isEmpty()) {
                ps.setString(10, currentUser.getCity());
            } else {
                ps.setString(10, City);
            }

            ps.setInt(11, userRole);
            
            ps.setInt(12, userId);

            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated;

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }
    
    public UserDTO getUserById(int userId) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        UserDTO user = null;

        try {
            con = DBUtils.getConnection(); 
            String sql = "SELECT fullName, userName, userPass, Sex, birth, phoneNumber, email, Street, District, City, userRole FROM [User] WHERE userID=?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            if (rs.next()) {
                String fullName = rs.getString("fullName");
                String userName = rs.getString("userName");
                String userPass = rs.getString("userPass");
                String Sex = rs.getString("Sex");
                Date birthDate = rs.getDate("birth");
                String phoneNumber = rs.getString("phoneNumber");
                String email = rs.getString("email");
                String Street = rs.getString("Street");
                String District = rs.getString("District");
                String City = rs.getString("City");
                Boolean userRole = rs.getBoolean("userRole");
                
                user = new UserDTO(userId, fullName, userName, userPass, phoneNumber, Sex, email, birthDate, Street, District, City, userRole);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return user;
    }
}
