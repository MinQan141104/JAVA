/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.discount;

/**
 *
 * @author DELL
 */
public class AdminDiscountDTO {
    private String code;
    private String detail;
    private float amount;
    private String startAt;
    private String endAt;
    private int limit;
    private String status;

    public AdminDiscountDTO() {
    }

    public AdminDiscountDTO(String code, String detail, float amount, String startAt, String endAt, int limit, String status) {
        this.code = code;
        this.detail = detail;
        this.amount = amount;
        this.startAt = startAt;
        this.endAt = endAt;
        this.limit = limit;
        this.status = status;
    }

 

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

  

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }


        public String getStartAt() {
        return startAt;
    }

    public void setStartAt(String startAt) {
        this.startAt = startAt;
    }

    public String getEndAt() {
        return endAt;
    }

    public void setEndAt(String endAt) {
        this.endAt = endAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "AdminDiscountDTO{" + "code=" + code + ", detail=" + detail + ", amount=" + amount + ", startAt=" + startAt + ", endAt=" + endAt + ", limit=" + limit + ", status=" + status + '}';
    }

    

 
    
    
    
    
    
}
