/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.discount;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import sample.utils.DBUtils;

/**
 *
 * @author DELL
 */
public class AdminDiscountDAO {

    public static final String SHOW = "select * from DiscountCode";
    public static final String ADD = "INSERT INTO [dbo].[DiscountCode]([code],[detail],[discountAmount],startDay,endDay,[usedLimit]) VALUES (?,?,?,?,?,?)";
    public static final String DELETE = "DELETE FROM [dbo].[DiscountCode] WHERE CODE = ?";

    public ArrayList<AdminDiscountDTO> getList() throws SQLException {
        ArrayList<AdminDiscountDTO> list = new ArrayList<>();
        AdminDiscountDTO dis = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(SHOW);
                rs = ps.executeQuery();
                while (rs.next()) {
                    String code = rs.getString(2);
                    String detail = rs.getString(3);
                    float amount = rs.getFloat(4);
                    String startAt = rs.getString(5);
                    String endAt = rs.getString(6);
                    int limit = rs.getInt(7);
                    int statusDB = rs.getInt(8);
                    String status = "Off";
                    if (statusDB == 1) {
                        status = "On";
                    }
                    dis = new AdminDiscountDTO(code, detail, amount, startAt, endAt, limit, status);
                    list.add(dis);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return list;
    }

  

    public boolean addNewDiscount(String code, String detail, float amount, Date startDay, Date endDay, int limit) throws SQLException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(ADD);
                ps.setString(1, code);
                ps.setString(2, detail);
                ps.setFloat(3, amount);
                ps.setDate(4, startDay);
                ps.setDate(5, endDay);
                ps.setInt(6, limit);
                int i = ps.executeUpdate();
                if (i == 1) {
                    check = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }

    public boolean deleteDiscountByCode(String code) throws SQLException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(DELETE);
                ps.setString(1, code);
                int i = ps.executeUpdate();
                if (i == 1) {
                    check = true;
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return check;
    }

  
    

}
