/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.brand;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

/**
 *
 * @author Layze
 */
public class BrandDAO {

    public List<BrandDTO> getAllBrands() throws SQLException, ClassNotFoundException {
        List<BrandDTO> brands = new ArrayList<>();
        String sql = "SELECT BrandID, BrandName FROM Brand";
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int brandID = rs.getInt("BrandID");
                String brandName = rs.getString("BrandName");
                brands.add(new BrandDTO(brandID, brandName));
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return brands;
    }

    public BrandDTO getBrandById(int brandID) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        BrandDTO brand = null;

        try {
            con = DBUtils.getConnection();
            String sql = "SELECT BrandName FROM Brand WHERE BrandID=?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, brandID);
            rs = ps.executeQuery();

            if (rs.next()) {
                String BrandName = rs.getString("BrandName");

                brand = new BrandDTO(brandID, BrandName);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return brand;
    }
}
