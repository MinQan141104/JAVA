/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.order;

/**
 *
 * @author DELL
 */
public class InforOrderDetail {

    private int proId, quantity;

    public InforOrderDetail() {
    }

    public InforOrderDetail(int proId, int quantity) {
        this.proId = proId;
        this.quantity = quantity;
    }

    public int getProId() {
        return proId;
    }

    public void setProId(int proId) {
        this.proId = proId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "InforOrderDetail{" + "proId=" + proId + ", quantity=" + quantity + '}';
    }

}
