/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.order;

/**
 *
 * @author DELL
 */
public class AdminOrderDTO {
    private int orderID;
    private int userID;
    private String fullName;
    private String phone;
    private String email;
    private String street;
    private String district;
    private String city;
    private String payMethod;
    private String shipMethod;
    private float totalPrice;
    private String createAt;
    private String status;

    public AdminOrderDTO() {
    }

    public AdminOrderDTO(int orderID, int userID, String fullName, String phone, String email, String street, String district, String city, String payMethod, String shipMethod, float totalPrice, String createAt, String status) {
        this.orderID = orderID;
        this.userID = userID;
        this.fullName = fullName;
        this.phone = phone;
        this.email = email;
        this.street = street;
        this.district = district;
        this.city = city;
        this.payMethod = payMethod;
        this.shipMethod = shipMethod;
        this.totalPrice = totalPrice;
        this.createAt = createAt;
        this.status = status;
    }

    

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    public String getShipMethod() {
        return shipMethod;
    }

    public void setShipMethod(String shipMethod) {
        this.shipMethod = shipMethod;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getCreateAt() {
        return createAt;
    }

    public void setCreateAt(String createAt) {
        this.createAt = createAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "AdminOrderDTO{" + "orderID=" + orderID + ", userID=" + userID + ", fullName=" + fullName + ", phone=" + phone + ", email=" + email + ", street=" + street + ", district=" + district + ", city=" + city + ", payMethod=" + payMethod + ", shipMethod=" + shipMethod + ", totalPrice=" + totalPrice + ", createAt=" + createAt + ", status=" + status + '}';
    }

    
    
    
    
    
}
