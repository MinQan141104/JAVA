/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.order;

/**
 *
 * @author DELL
 */
public class AdminOrderDetailDTO {
    private int orderDetailID;
    private int productID; 
    private int OrderID ;
    private String pathImg;
    private String productName;
    private int quantity; 
    private float unitPrice; 
    private float salePrice; 
    private String CreatedAt;

    public AdminOrderDetailDTO() {
    }

    public AdminOrderDetailDTO(int orderDetailID, int productID, int OrderID, String pathImg, String productName, int quantity, float unitPrice, float salePrice, String CreatedAt) {
        this.orderDetailID = orderDetailID;
        this.productID = productID;
        this.OrderID = OrderID;
        this.pathImg = pathImg;
        this.productName = productName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.salePrice = salePrice;
        this.CreatedAt = CreatedAt;
    }

    public float getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(float salePrice) {
        this.salePrice = salePrice;
    }

   

    public String getPathImg() {
        return pathImg;
    }

    public void setPathImg(String pathImg) {
        this.pathImg = pathImg;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

   
    public int getOrderDetailID() {
        return orderDetailID;
    }

    public void setOrderDetailID(int orderDetailID) {
        this.orderDetailID = orderDetailID;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int OrderID) {
        this.OrderID = OrderID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(float unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getCreatedAt() {
        return CreatedAt;
    }

    public void setCreatedAt(String CreatedAt) {
        this.CreatedAt = CreatedAt;
    }

    @Override
    public String toString() {
        return "AdminOrderDetailDTO{" + "orderDetailID=" + orderDetailID + ", productID=" + productID + ", OrderID=" + OrderID + ", pathImg=" + pathImg + ", productName=" + productName + ", quantity=" + quantity + ", unitPrice=" + unitPrice + ", CreatedAt=" + CreatedAt + '}';
    }

   
    
    
}
