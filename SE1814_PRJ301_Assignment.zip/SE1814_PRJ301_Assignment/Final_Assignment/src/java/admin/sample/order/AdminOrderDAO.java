/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import sample.utils.DBUtils;

/**
 *
 * @author DELL
 */
public class AdminOrderDAO {

    public static final String SHOW_ORDER_LIST = "SELECT * FROM DBO.ORDER_TABLE";
    public static final String SHOW_ORDER = "select * from dbo.[ViewOrderByOderID] (?)";
    public static final String VIEW_ORDER_DETAIL = "select * from dbo.ViewOrderDetailByOderID (?)";
    private static final String INSERT_ORDER = "INSERT INTO [Order] (UserID, fullName, phoneNumber, email, Street, District, City, PaymentMethodID, ShippingMethodID)\n"
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String INSERT_ORDER_DETAIL = "INSERT INTO OrderDetail (ProductID, OrderID, quantity, unitPrice, afterSalePrice)\n"
            + "VALUES (?, ?, ?, ?, ?)";
    private static final String DISCOUNT_ON_ORDER = "INSERT INTO Order_Discount (Order_ID, Discount_ID)\n"
            + "VALUES (?, ?)";
    private static final String USE_CODE_FIND_DISCOUNT_ID = "select * from DiscountCode where code = ? ";
    private static final String UPDATE_ORDER_STATUS = "UPDATE [ORDER] SET order_status = ? WHERE OrderID = ?";

// lẤY DỮ LIỆU TỪ DATABASE 
    public ArrayList<AdminOrderDTO> getOrderList() throws SQLException {
        ArrayList<AdminOrderDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(SHOW_ORDER_LIST);
                rs = ps.executeQuery();
                while (rs.next()) {
                    int orderID = rs.getInt(1);
                    int userID = rs.getInt(2);
                    String fullName = rs.getString(3);
                    String phone = rs.getString(4);
                    String email = rs.getString(5);
                    String street = rs.getString(6);
                    String district = rs.getString(7);
                    String city = rs.getString(8);
                    String payMethod = rs.getString(9);
                    String shipMethod = rs.getString(10);
                    float totalPrice = rs.getFloat(11);
                    String createAt = rs.getString(12);
                    String status = rs.getString(13);
                    AdminOrderDTO o = new AdminOrderDTO(orderID, userID, fullName, phone, email,
                            street, district, city, payMethod, shipMethod, totalPrice, createAt, status);
                    list.add(o);

                }

            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return list;
    }

    public ArrayList<AdminOrderDTO> getSucessOrderList() throws SQLException {
        ArrayList<AdminOrderDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(SHOW_ORDER_LIST);
                rs = ps.executeQuery();
                while (rs.next()) {
                    int orderID = rs.getInt(1);
                    int userID = rs.getInt(2);
                    String fullName = rs.getString(3);
                    String phone = rs.getString(4);
                    String email = rs.getString(5);
                    String street = rs.getString(6);
                    String district = rs.getString(7);
                    String city = rs.getString(8);
                    String payMethod = rs.getString(9);
                    String shipMethod = rs.getString(10);
                    float totalPrice = rs.getFloat(11);
                    String createAt = rs.getString(12);
                    String status = rs.getString(13);
                    if (status.equals("Shipped")) {
                        AdminOrderDTO o = new AdminOrderDTO(orderID, userID, fullName, phone, email,
                                street, district, city, payMethod, shipMethod, totalPrice, createAt, status);
                        list.add(o);
                    }

                }

            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return list;
    }

    public AdminOrderDTO getOrderByOrderID(int OrderID) throws SQLException {
        AdminOrderDTO o = new AdminOrderDTO();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(SHOW_ORDER);
                ps.setInt(1, OrderID);
                rs = ps.executeQuery();
                if (rs.next()) {
                    int orderID = rs.getInt(1);
                    int userID = rs.getInt(2);
                    String fullName = rs.getString(3);
                    String phone = rs.getString(4);
                    String email = rs.getString(5);
                    String street = rs.getString(6);
                    String district = rs.getString(7);
                    String city = rs.getString(8);
                    String payMethod = rs.getString(9);
                    String shipMethod = rs.getString(10);
                    float totalPrice = rs.getFloat(11);
                    String createAt = rs.getString(12);
                    String status = rs.getString(13);
                    o = new AdminOrderDTO(orderID, userID, fullName, phone, email,
                            street, district, city, payMethod, shipMethod, totalPrice, createAt, status);

                }

            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return o;
    }

    public ArrayList<AdminOrderDetailDTO> getOrderDetailListByOrderID(int OrderID) throws SQLException {

        ArrayList<AdminOrderDetailDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(VIEW_ORDER_DETAIL);
                ps.setInt(1, OrderID);
                rs = ps.executeQuery();
                while (rs.next()) {
                    int orderDetailID = rs.getInt(1);
                    int productID = rs.getInt(2);
                    int orderID = rs.getInt(3);
                    String pathImg = rs.getString(4);
                    String prodcutName = rs.getString(5);
                    int quantity = rs.getInt(6);
                    float price = rs.getFloat(7);
                    float salePrice = rs.getFloat(8);
                    String createAt = rs.getString(9);
                    AdminOrderDetailDTO od = new AdminOrderDetailDTO(orderDetailID, productID, orderID, pathImg, prodcutName, quantity, price, salePrice, createAt);
                    list.add(od);
                }

            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return list;
    }

    // CẬP NHẬT, THÊM, SỬA DŨ LIỆU XUỐNG DATABASE 
    // tạo hóa đơn
    public int insertOrder_GetOrderID(int uid, String fullName, String phone, String email, String street, String district, String city, int pay, int ship) throws SQLException {
        int orderID = -1;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(INSERT_ORDER, PreparedStatement.RETURN_GENERATED_KEYS);
                ps.setInt(1, uid);
                ps.setString(2, fullName);
                ps.setString(3, phone);
                ps.setString(4, email);
                ps.setString(5, street);
                ps.setString(6, district);
                ps.setString(7, city);
                ps.setInt(8, pay);
                ps.setInt(9, ship);
                int i = ps.executeUpdate();
                if (i > 0) {
                    rs = ps.getGeneratedKeys();
                    if (rs.next()) {
                        orderID = rs.getInt(1);
                    } else {
                        throw new SQLException("Creating order failed, no ID obtained.");
                    }
                }

            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return orderID;
    }

    public static void main(String[] args) throws SQLException {
        AdminOrderDAO d = new AdminOrderDAO();
        boolean check = d.createOrderDetail(5, 2, 2, 50, 25);
        System.out.println(check);
    }
// cập nhật trạng thái hóa đơn

    public boolean updateOrderStatus(int orderID, String status) throws SQLException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            if(conn!=null){
                ps = conn.prepareStatement(UPDATE_ORDER_STATUS);
                ps.setString(1, status);
                ps.setInt(2, orderID);
                int i = ps.executeUpdate();
                if(i>0){
                    check = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {}
        finally{
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        
        
        return check;
    }

// tạo hóa đơn chi tiết
    public boolean createOrderDetail(int pid, int orderId, int quantity, float price, float salePrice) throws SQLException {
        boolean check = false;

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(INSERT_ORDER_DETAIL);
                ps.setInt(1, pid);
                ps.setInt(2, orderId);
                ps.setInt(3, quantity);
                ps.setFloat(4, price);
                ps.setFloat(5, salePrice);
                int i = ps.executeUpdate();
                if (i > 0) {
                    check = true;
                }

            }

        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }
    
    // check discount id by code
    public int getDiscountIdByCode(String code) throws SQLException {
        int i = 0;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(USE_CODE_FIND_DISCOUNT_ID);
                ps.setString(1, code);
                rs = ps.executeQuery();
                if (rs.next()) {
                    i = rs.getInt(1);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return i;
    }

    // quan hệ giữa discount code và order
    public boolean discountOnOrder(int oId, int disId) throws SQLException {
        boolean check = false;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(DISCOUNT_ON_ORDER);
                ps.setInt(1, oId);
                ps.setInt(2, disId);
                int i = ps.executeUpdate();
                if (i > 0) {
                    check = true;
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }

}
