/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.categories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

/**
 *
 * @author Layze
 */
public class CategoriesDAO {

    public List<CategoriesDTO> getAllCategories() throws SQLException, ClassNotFoundException {
        List<CategoriesDTO> categories = new ArrayList<>();
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBUtils.getConnection();
            String sql = "SELECT u.userObjectID, u.userObjectName, u.detail, "
                    + "(SELECT COUNT(*) FROM Product p WHERE p.userObjectID = u.userObjectID) AS productCount "
                    + "FROM userObject u";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                int userObjectID = rs.getInt("userObjectID");
                String userObjectName = rs.getString("userObjectName");
                String detail = rs.getString("detail");
                int productCount = rs.getInt("productCount");

                CategoriesDTO category = new CategoriesDTO(userObjectID, userObjectName, detail, productCount);
                categories.add(category);
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return categories;
    }

    public boolean createCategory(String userObjectName, String detail) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        boolean result = false;

        try {
            con = DBUtils.getConnection();
            String sql = "INSERT INTO userObject (userObjectName, detail) VALUES (?, ?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, userObjectName);
            ps.setString(2, detail);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                result = true;
            }
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return result;
    }

    public int getProductCount(int userObjectID) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int productCount = 0;

        try {
            con = DBUtils.getConnection();
            String sql = "SELECT COUNT(*) as productCount FROM Product WHERE userObjectID = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, userObjectID);
            rs = ps.executeQuery();

            if (rs.next()) {
                productCount = rs.getInt("productCount");
            }
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return productCount;
    }

    public boolean removeCategory(int userObjectID) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        boolean result = false;

        try {
            con = DBUtils.getConnection();
            String sql = "DELETE FROM userObject WHERE userObjectID = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, userObjectID);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                result = true;
            }
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return result;
    }

    public boolean updateCategory(int userObjectID, String userObjectName, String detail) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBUtils.getConnection();
            String sql = "UPDATE userObject SET userObjectName = ?, detail = ? WHERE userObjectID = ?";
            ps = con.prepareStatement(sql);

            CategoriesDTO currentCategory = getCategoryById(userObjectID);

            if (userObjectName == null || userObjectName.isEmpty()) {
                ps.setString(1, currentCategory.getUserObjectName());
            } else {
                ps.setString(1, userObjectName);
            }

            if (detail == null || detail.isEmpty()) {
                ps.setString(2, currentCategory.getDetail());
            } else {
                ps.setString(2, detail);
            }

            ps.setInt(3, userObjectID);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }

    public CategoriesDTO getCategoryById(int userObjectID) throws SQLException, ClassNotFoundException {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        CategoriesDTO category = null;

        try {
            con = DBUtils.getConnection();
            String sql = "SELECT userObjectName, detail FROM userObject WHERE userObjectID=?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, userObjectID);
            rs = ps.executeQuery();

            if (rs.next()) {
                String userObjectName = rs.getString("userObjectName");
                String detail = rs.getString("detail");

                category = new CategoriesDTO(userObjectName, detail);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return category;
    }
}
