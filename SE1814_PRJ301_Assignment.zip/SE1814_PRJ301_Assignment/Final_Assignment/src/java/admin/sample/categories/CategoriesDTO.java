/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.sample.categories;

/**
 *
 * @author Layze
 */
public class CategoriesDTO {

    private int userObjectID;
    private String userObjectName;
    private String detail;
    private int productCount;

    public CategoriesDTO(int userObjectID, String userObjectName, String detail, int productCount) {
        this.userObjectID = userObjectID;
        this.userObjectName = userObjectName;
        this.detail = detail;
        this.productCount = productCount;
    }

    public CategoriesDTO(String userObjectName, String detail) {
        this.userObjectName = userObjectName;
        this.detail = detail;
    }

    public int getUserObjectID() {
        return userObjectID;
    }

    public void setUserObjectID(int userObjectID) {
        this.userObjectID = userObjectID;
    }

    public String getUserObjectName() {
        return userObjectName;
    }

    public void setUserObjectName(String userObjectName) {
        this.userObjectName = userObjectName;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public int getProductCount() {
        return productCount;
    }

    public void setProductCount(int productCount) {
        this.productCount = productCount;
    }

}
