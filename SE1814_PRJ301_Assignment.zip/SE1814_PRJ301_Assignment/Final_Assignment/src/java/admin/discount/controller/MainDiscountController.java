/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.discount.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DELL
 */
@WebServlet(name = "MainDiscountController", urlPatterns = {"/MainDiscountController"})
public class MainDiscountController extends HttpServlet {

    public final static String ERROR = "discountList.jsp";

    //-----------------------Discount------------------------------------
    public final static String ADD_DISCOUNT = "Add";
    public final static String ADD_DISCOUNT_CONTROLLER = "AddNewDiscountController";
 
    public final static String REMOVE_DISCOUNT = "Remove";
    public final static String REMOVE_DISCOUNT_CONTROLLER = "RemoveDiscountController";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String url = ERROR;

        try {
            if (action.equals(ADD_DISCOUNT)) {
                url = ADD_DISCOUNT_CONTROLLER;
            }
            if (action.equals(REMOVE_DISCOUNT)) {
                url = REMOVE_DISCOUNT_CONTROLLER;
            }
           
        } catch (Exception e) {
            log("Error at MainController:" + e.toString());
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
