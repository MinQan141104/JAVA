/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.discount.controller;


import admin.sample.discount.AdminDiscountDAO;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DELL
 */
@WebServlet(name = "AddNewDiscountController", urlPatterns = {"/AddNewDiscountController"})
public class AddNewDiscountController extends HttpServlet {

    public final static String ERROR = "discountList.jsp";
    public final static String SUCCESS = "discountList.jsp";
   

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String code = request.getParameter("code");
        String detail = request.getParameter("detail");
        float amount = Float.parseFloat(request.getParameter("amount"));
        String startDayString = request.getParameter("startDay");
        String endDayString = request.getParameter("endDay");
        int limit = Integer.parseInt(request.getParameter("limit"));
        String url = ERROR;
        
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate ldStartDay = LocalDate.parse(startDayString, df);
         LocalDate ldEndDay = LocalDate.parse(endDayString, df);
         Date startDay = Date.valueOf(ldStartDay);
         Date endDay = Date.valueOf(ldEndDay);
        try {
            AdminDiscountDAO d = new AdminDiscountDAO();
            
        
            boolean check = d.addNewDiscount(code, detail, amount, startDay, endDay,limit);
            if(check){
                request.setAttribute("ms", "Add Successfully");
                url = SUCCESS;
            }else{
                request.setAttribute("err", "Something wrong at sever");
            }
            
        } catch (SQLException e) {}
        finally{
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
