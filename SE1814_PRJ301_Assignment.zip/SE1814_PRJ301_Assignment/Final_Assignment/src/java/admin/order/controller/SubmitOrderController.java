/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.order.controller;

import admin.sample.order.AdminOrderDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.CartDTO;
import model.ItemDTO;
import model.ProductDAO;
import model.ProductDTO;

/**
 *
 * @author DELL
 */
@WebServlet(name = "SubmitOrderController", urlPatterns = {"/SubmitOrderController"})
public class SubmitOrderController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet SubmitOrderController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet SubmitOrderController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    private static final String ERROR = "check-out.jsp";
    private static final String SUCCESS = "success.jsp";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = ERROR;

        try {
            int uid = Integer.parseInt(request.getParameter("userId"));
            String fullName = request.getParameter("fullname");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String street = request.getParameter("street");
            String district = request.getParameter("district");
            String city = request.getParameter("city");
            int pay = Integer.parseInt(request.getParameter("pay"));
            int ship = Integer.parseInt(request.getParameter("ship"));
            String discount = request.getParameter("discount");
            HttpSession session = request.getSession();
            CartDTO cart = (CartDTO) session.getAttribute("CART");
            List<ItemDTO> ls = cart.getList();
            // ----------------------------------------------------
            AdminOrderDAO d = new AdminOrderDAO();

            int orderId;

            orderId = d.insertOrder_GetOrderID(uid, fullName, phone, email, street, district, city, pay, ship);
            int discountId = d.getDiscountIdByCode(discount);

            if (discountId != 0) {

                boolean check = d.discountOnOrder(orderId, discountId);
                request.setAttribute("ms-d", "find discount:  oke");
                if (check) {
                    request.setAttribute("ms-do", "relationship discount at order:  oke");
                } else {
                    request.setAttribute("ms-do", "relationship discount at order: not oke");
                }
            } else {
                request.setAttribute("ms-d", "find discount: not oke");
            }
            if (orderId != 0) {
                for (ItemDTO ele : ls) {

                    int pId = ele.getProduct().getProductId();
                    int quantity = ele.getQuantity();

                    ProductDAO pd = new ProductDAO();
                    ProductDTO pro = pd.getProductbyId2(pId);

                    float price = pro.getPrice();
                    float salePrice = pro.getPrice() * (1 - pro.getSale());
                    boolean check = d.createOrderDetail(pId, orderId, quantity, price, salePrice);
                    url = SUCCESS;
                }
            }
            CartDTO cart_new = new CartDTO();
            session.setAttribute("CART", cart_new);
             session.setAttribute("size","0");

        } catch (NumberFormatException e) {
            log("Error at Submit Order Controller:" + e.toString());
        } catch (SQLException ex) {
            Logger.getLogger(SubmitOrderController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
