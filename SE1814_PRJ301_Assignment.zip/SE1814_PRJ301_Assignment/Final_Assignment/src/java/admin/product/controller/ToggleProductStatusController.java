/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.product.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import admin.sample.product.ProductDAO;

/**
 *
 * @author Layze
 */
@WebServlet(name = "ToggleProductStatusController", urlPatterns = {"/ToggleProductStatusController"})
public class ToggleProductStatusController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private ProductDAO productDao;

    public void init() throws ServletException {
        super.init();
        productDao = new ProductDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productIdStr = request.getParameter("productId");

        if (productIdStr != null && !productIdStr.isEmpty()) {
            int productId = Integer.parseInt(productIdStr);
            try {
                productDao.toggleProductStatus(productId);
                response.sendRedirect(request.getContextPath() + "/productList.jsp");
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();

                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to toggle product status");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Product ID parameter is missing");
        }
    }
}
