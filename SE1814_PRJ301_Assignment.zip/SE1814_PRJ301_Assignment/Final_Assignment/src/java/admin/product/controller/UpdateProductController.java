/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.product.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import admin.sample.product.ProductDAO;
import admin.sample.product.ProductDTO;
import admin.sample.product.Product_ImagesDAO;
import admin.sample.product.Product_ImagesDTO;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Layze
 */
@WebServlet(name = "UpdateProductController", urlPatterns = {"/UpdateProductController"})
public class UpdateProductController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private ProductDAO productDao;

    public void init() throws ServletException {
        productDao = new ProductDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int productId = Integer.parseInt(request.getParameter("productId"));

            ProductDTO currentProduct = productDao.getProductById(productId);

            String name = request.getParameter("name");
            if (name == null || name.isEmpty()) {
                name = currentProduct.getName();
            }

            int userObjectID;
            String userObjectIDStr = request.getParameter("userObjectID");
            if (userObjectIDStr == null || userObjectIDStr.isEmpty()) {
                userObjectID = currentProduct.getUserObjectID();
            } else {
                userObjectID = Integer.parseInt(userObjectIDStr);
            }

            int brandID;
            String brandIDStr = request.getParameter("brandID");
            if (brandIDStr == null || brandIDStr.isEmpty()) {
                brandID = currentProduct.getBrandID();
            } else {
                brandID = Integer.parseInt(brandIDStr);
            }

            double price;
            String priceStr = request.getParameter("price");
            if (priceStr == null || priceStr.isEmpty()) {
                price = currentProduct.getPrice();
            } else {
                price = Double.parseDouble(priceStr);
            }

            float sale;
            String saleStr = request.getParameter("sale");
            if (saleStr == null || saleStr.isEmpty()) {
                sale = currentProduct.getSale();
            } else {
                sale = Float.parseFloat(saleStr);
            }

            String avatar = request.getParameter("avatar");
            if (avatar == null || avatar.isEmpty()) {
                avatar = currentProduct.getAvatar();
            }

            String color = request.getParameter("color");
            if (color == null || color.isEmpty()) {
                color = currentProduct.getColor();
            }

            float size;
            String sizeStr = request.getParameter("size");
            if (sizeStr == null || sizeStr.isEmpty()) {
                size = currentProduct.getSize();
            } else {
                size = Float.parseFloat(sizeStr);
            }

            int stock;
            String stockStr = request.getParameter("stock");
            if (stockStr == null || stockStr.isEmpty()) {
                stock = currentProduct.getStock();
            } else {
                stock = Integer.parseInt(stockStr);
            }

            String detail = request.getParameter("detail");
            if (detail == null || detail.isEmpty()) {
                detail = currentProduct.getDetail();
            }

            ProductDTO updatedProduct = new ProductDTO(productId, brandID, userObjectID, detail, name, avatar, price, color, size, stock, sale);

            try {
                int rowsAffected = productDao.updateProduct(updatedProduct);
                if (rowsAffected > 0) {
                    request.setAttribute("ms", "Product updated successfully");
                } else {
                    request.setAttribute("err", "Failed to update product");
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }

        } catch (NumberFormatException | SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("err", "Failed to update product");
            return;
        }

        try {
            request.getRequestDispatcher("productList.jsp").forward(request, response);
        } catch (IllegalStateException ex) {
            ex.printStackTrace();

        }
    }
}
