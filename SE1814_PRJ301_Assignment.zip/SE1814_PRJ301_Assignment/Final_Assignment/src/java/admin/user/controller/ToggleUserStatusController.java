/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.user.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import admin.sample.user.UserDAO;

/**
 *
 * @author Layze
 */
@WebServlet(name = "ToggleUserStatusController", urlPatterns = {"/ToggleUserStatusController"})
public class ToggleUserStatusController extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UserDAO userDao;

    public void init() throws ServletException {
        super.init();
        userDao = new UserDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userIdStr = request.getParameter("userId");

        if (userIdStr != null && !userIdStr.isEmpty()) {
            int userId = Integer.parseInt(userIdStr);
            try {
                userDao.toggleUserStatus(userId);
                response.sendRedirect(request.getContextPath() + "/userList.jsp");
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();

                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to toggle user status");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID parameter is missing");
        }
    }
}
