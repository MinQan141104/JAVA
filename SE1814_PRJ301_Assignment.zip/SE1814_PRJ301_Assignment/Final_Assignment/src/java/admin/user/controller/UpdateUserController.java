/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.user.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import admin.sample.user.UserDAO;

/**
 *
 * @author Layze
 */
@WebServlet(name = "UpdateUserController", urlPatterns = {"/UpdateUserController"})
public class UpdateUserController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int userId = Integer.parseInt(request.getParameter("userId"));
        String userName = request.getParameter("userName");
        String fullName = request.getParameter("fullName");
        String userPass = request.getParameter("userPass");
        String phoneNumber = request.getParameter("phoneNumber");
        String Sex = request.getParameter("Sex");
        String email = request.getParameter("email");
        String birth = request.getParameter("birth");
        String Street = request.getParameter("Street");
        String District = request.getParameter("District");
        String City = request.getParameter("City");
        int userRole = Integer.parseInt(request.getParameter("userRole"));

        UserDAO userDao = new UserDAO();

        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date birthDate = null;
            if (birth != null && !birth.isEmpty()) {
                birthDate = new Date(dateFormat.parse(birth).getTime());
            }

            int rowsUpdated = userDao.updateUser(userId, fullName, userName, userPass, Sex, birthDate, phoneNumber, email, Street, District, City, userRole);

            if (rowsUpdated > 0) {
                request.setAttribute("ms", "User updated successfully");
            } else {
                request.setAttribute("err", "Updating user failed, no rows affected." + userId);
            }

        } catch (ParseException ex) {
            ex.printStackTrace();
            request.setAttribute("err", "Invalid date format. Please use YYYY-MM-DD.");
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            request.setAttribute("err", "Failed to update user: " + ex.getMessage());
        }

        request.getRequestDispatcher("userList.jsp").forward(request, response);
    }

}
