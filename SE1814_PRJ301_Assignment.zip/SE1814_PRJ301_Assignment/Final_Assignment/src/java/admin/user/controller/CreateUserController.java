/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.user.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;


import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import admin.sample.user.UserDAO;

/**
 *
 * @author Layze
 */
@WebServlet(name = "CreateUserController", urlPatterns = {"/CreateUserController"})
public class CreateUserController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        
        String userName = request.getParameter("userName");
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String userPass = request.getParameter("userPass");
        String confirmPass = request.getParameter("confirm"); 
        String Sex = request.getParameter("Sex"); 
        String birth = request.getParameter("birth");
        String phoneNumber = request.getParameter("phoneNumber");
        String Street = request.getParameter("Street");
        String District = request.getParameter("District");
        String City = request.getParameter("City");
        int userRole = Integer.parseInt(request.getParameter("userRole"));

        boolean isActive = true; 

        if (!userPass.equals(confirmPass)) {
            request.setAttribute("err", "Passwords do not match.");
            request.getRequestDispatcher("userList.jsp").forward(request, response);
            return; 
        }

        Date birthdate = null;
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            birthdate = new Date(formatter.parse(birth).getTime());
        } catch (ParseException ex) {
            request.setAttribute("err", "Invalid date format. Please use yyyy-MM-dd.");
            request.getRequestDispatcher("userList.jsp").forward(request, response);
            return;
        }
        UserDAO userDao = new UserDAO();

        try {
            if (userDao.isUserNameExists(userName)) {
                request.setAttribute("err", "Username already exists. Please choose a different username.");
                request.getRequestDispatcher("userList.jsp").forward(request, response);
                return; 
            }

            userDao.createUser(fullName, userName, userPass, Sex, birthdate, phoneNumber, email, Street, District, City, isActive, userRole);

            request.setAttribute("ms", "User created successfully");

        } catch (SQLException | ClassNotFoundException ex) {
            request.setAttribute("err", "Failed to create user: " + ex.getMessage());
        }

        request.getRequestDispatcher("userList.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(CreateUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(CreateUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
