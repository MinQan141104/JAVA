/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin.category.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import admin.sample.categories.CategoriesDAO;

/**
 *
 * @author Layze
 */
@WebServlet(name = "CreateCategoryController", urlPatterns = {"/CreateCategoryController"})
public class CreateCategoryController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userObjectName = request.getParameter("userObjectName");
        String detail = request.getParameter("detail");

        CategoriesDAO categoriesDAO = new CategoriesDAO();

        try {
            boolean isCreated = categoriesDAO.createCategory(userObjectName, detail);
            if (isCreated) {
                request.setAttribute("ms", "Category created successfully");
            } else {
                request.setAttribute("err", "Failed to create category");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("err", "An error occurred: " + e.getMessage());
        }

        request.getRequestDispatcher("categoriesList.jsp").forward(request, response);
    }
}
