/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Luu Minh Quan
 */
public class CartDTO {

    private ArrayList<ItemDTO> list;
    private String userId;

    public CartDTO() {
        list = new ArrayList<>();
    }

    public CartDTO(ArrayList<ItemDTO> list, String userId) {
        this.list = list;
        this.userId = userId;
    }

    public ArrayList<ItemDTO> getList() {
        return list;
    }

    public void setList(ArrayList<ItemDTO> list) {
        this.list = list;
    }

    private ItemDTO getItemById(int id) {
        ItemDTO item = list.get(id);

        return item;
    }

    public boolean ExistedProduct(int id, float size){
        boolean item = false;
        for (ItemDTO itemDTO : list) {
            if(itemDTO.getProduct().getProductId() == id && (itemDTO.getSize() == size)){
                item = true;
            }
        }
        return item;
    }
    public int getQuantityById(int id) {
        return getItemById(id).getQuantity();
    }

    public void addItem(ItemDTO t) {
        list.add(t);
    }

    public void addItemExist(ItemDTO t) {
        for (ItemDTO itemDTO : list) {
            if ((itemDTO.getProduct().getProductId() == t.getProduct().getProductId()) && (itemDTO.getSize() == t.getSize())) {
                    itemDTO.setQuantity(itemDTO.getQuantity() + t.getQuantity());
            }
        }

    }

    public void updateQuantity(int id, int newQuantity) {
//        if (getItemById(id) != null) {
        ItemDTO item = list.get(id);
        item.setQuantity(item.getQuantity() + newQuantity);
//        }
    }

    public void removeItem(int id) {
        ItemDTO item = list.get(id);
        list.remove(item);
    }

    public double getTotalPrice() {

        double subToltal = 0;
        for (ItemDTO itemDTO : list) {
            subToltal += itemDTO.getQuantity() * itemDTO.getPrice();
        }
        return subToltal;
    }

    public int getSize() {
        if (this.list != null) {
            return this.list.size();
        } else {
            return 0; // Trả về 0 nếu giỏ hàng chưa được khởi tạo
        }
    }

}
