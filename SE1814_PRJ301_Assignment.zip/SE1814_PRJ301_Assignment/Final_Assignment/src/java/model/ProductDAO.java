/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

/**
 *
 * @author Luu Minh Quan
 */
public class ProductDAO {

    public List<ProductDTO> getProductList() {
        String sql = "SELECT * FROM Product WHERE Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public int DeleteWishlist(int userID, int productID) {
        int check = 0;
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "delete from Wishlist where userID=? and productID=?";
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setInt(1, userID);
                ps.setInt(2, productID);
                check = ps.executeUpdate();
            }
        } catch (Exception e) {
        }
        return check;
    }

    public List<ProductDTO> getAllProductListWish(int id) {
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "select * from Product P INNER JOIN Wishlist W on p.ProductID = w.ProductID where userID=? order by createdAt DESC";
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getProductListWishSort(String id, int userID) {
        String sql = "";
        if (id.equals("1")) {
            sql = "select * from Product P INNER JOIN Wishlist W on p.ProductID = w.ProductID where userID=? order by createdAt DESC";
        } else if (id.equals("2")) {
            sql = "SELECT * FROM Product P,Wishlist W WHERE Sale != 0 and userID=? and p.ProductID = w.ProductID";
        } else if (id.equals("3")) {
            sql = "SELECT *, \n"
                    + "       CASE \n"
                    + "           WHEN sale != 0 THEN price * (1 - sale) \n"
                    + "           ELSE price \n"
                    + "       END AS final_price\n"
                    + "FROM Product P,Wishlist W\n"
                    + "where userID=? and p.ProductID = w.ProductID\n"
                    + "ORDER BY final_price DESC;";
        } else if (id.equals("4")) {
            sql = "SELECT *, \n"
                    + "       CASE \n"
                    + "           WHEN sale != 0 THEN price * (1 - sale) \n"
                    + "           ELSE price \n"
                    + "       END AS final_price\n"
                    + "FROM Product P,Wishlist W\n"
                    + "where userID=? and p.ProductID = w.ProductID\n"
                    + "ORDER BY final_price ASC;";
        }
        if (id.equals("5")) {
            sql = "SELECT * \n"
                    + "FROM Product P,Wishlist W\n"
                    + "where userID=? and p.ProductID = w.ProductID\n"
                    + "ORDER BY Name;";
        }
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setInt(1, userID);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public int InsertWishlist(int userID, int productID) {
        int check = 0;
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "insert into Wishlist(userID,ProductID) values(?,?)";
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setInt(1, userID);
                ps.setInt(2, productID);
                check = ps.executeUpdate();
            }
        } catch (Exception e) {
        }
        return check;
    }

    public Code ApplyCode(String code) {
        String sql = "SELECT * FROM DiscountCode WHERE code = ? and discount_status = 1";
        Connection conn = null;
        PreparedStatement ps = null;
        Code check = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, code);
                rs = ps.executeQuery();
                if (rs.next()) {
                    check = new Code(rs.getString("code"),
                            rs.getString("detail"),
                            rs.getDouble("discountAmount"),
                            rs.getString("startDay"),
                            rs.getString("endDay"),
                            rs.getInt("usedLimit"));
                }
            }
        } catch (Exception e) {
        }
        return check;
    }

    public ProductDTO getProductbyId(String id) {
        String sql = "SELECT * FROM product WHERE ProductID = ? and Product_Status = 1";
        ProductDTO p = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, id);
                rs = ps.executeQuery();
                if (rs.next()) {
                    p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));

                }
            }
        } catch (Exception e) {
        }
        return p;
    }
      public ProductDTO getProductbyId2(int id) {
        String sql = "SELECT * FROM product WHERE ProductID = ? and Product_Status = 1";
        ProductDTO p = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                rs = ps.executeQuery();
                if (rs.next()) {
                    p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));

                }
            }
        } catch (Exception e) {
        }
        return p;
    }

    public List<ProductDTO> getRelatedProductList() {
        String sql = "SELECT TOP 4 * FROM Product WHERE Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getProductListSort(String id) {
        String sql = "";
        if (id.equals("2")) {
            sql = "SELECT * FROM Product WHERE Sale != 0 and Hot = 1 and Product_Status = 1";
        } else if (id.equals("3")) {
            sql = "SELECT *, \n"
                    + "       CASE \n"
                    + "           WHEN sale != 0 THEN price * (1 - sale) \n"
                    + "           ELSE price \n"
                    + "       END AS final_price\n"
                    + "FROM Product\n WHERE Hot = 1 and Product_Status = 1"
                    + "ORDER BY final_price DESC;";
        } else {
            sql = "SELECT *, \n"
                    + "       CASE \n"
                    + "           WHEN sale != 0 THEN price * (1 - sale) \n"
                    + "           ELSE price \n"
                    + "       END AS final_price\n"
                    + "FROM Product\n WHERE Hot = 1 and Product_Status = 1"
                    + "ORDER BY final_price ASC;";
        }
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> search(String temp) throws SQLException {
        String sql = "SELECT * FROM Product WHERE Name LIKE ? and Hot = 1 and Product_Status = 1";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ProductDTO> ls = new ArrayList<>();

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, "%" + temp + "%");
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    ls.add(p);
                }
            }
        } catch (Exception e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return ls;
    }

    public List<ProductDTO> Filter(int[] brands, String minPrice, String maxPrice) {
        StringBuilder sql = new StringBuilder("SELECT * FROM Product WHERE 1 = 1 and Hot = 1 and Product_Status = 1");
        List<ProductDTO> ls = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                if (brands != null && brands.length > 0) {
                    sql.append(" AND BrandID IN (");
                    for (int i = 0; i < brands.length; i++) {
                        sql.append("?");
                        if (i < brands.length - 1) {
                            sql.append(",");
                        }
                    }
                    sql.append(")");
                }

                if (minPrice != null && !minPrice.isEmpty()) {
                    sql.append(" AND Price >= ?");
                }

                if (maxPrice != null && !maxPrice.isEmpty()) {
                    sql.append(" AND Price <= ?");
                }
                ps = conn.prepareStatement(sql.toString());
                int paramIndex = 1;

                if (brands != null && brands.length > 0) {
                    for (int brand : brands) {
                        ps.setInt(paramIndex++, brand);
                    }
                }

                if (minPrice != null && !minPrice.isEmpty()) {
                    ps.setDouble(paramIndex++, Double.parseDouble(minPrice));
                }

                if (maxPrice != null && !maxPrice.isEmpty()) {
                    ps.setDouble(paramIndex++, Double.parseDouble(maxPrice));
                }
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    ls.add(p);
                }
            }
        } catch (Exception e) {
        }
        return ls;
    }

    public List<Float> getSizesByProductId(String name) throws ClassNotFoundException {
        List<Float> sizes = new ArrayList<>();
        Connection conn = null;
        try {
            String sql = "SELECT Size FROM Product WHERE Name = ? and Product_Status = 1";
            conn = DBUtils.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                sizes.add(rs.getFloat("size"));
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sizes;
    }

    public List<ProductIMG> getImgbyId(String id) {
        String sql = "SELECT * FROM Product_Images WHERE ProductID = ?";
        List<ProductIMG> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, id);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductIMG p = new ProductIMG(rs.getInt("id"),
                            rs.getString("productId"),
                            rs.getString("path"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getTopMenList() {
        String sql = "SELECT TOP 5 * FROM product WHERE userObjectID = 1 and Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getMenList() {
        String sql = "SELECT * FROM product WHERE userObjectID = 1 and Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getKidList() {
        String sql = "SELECT * FROM product WHERE userObjectID = 3 and Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getTopWomenList() {
        String sql = "SELECT TOP 5 * FROM product WHERE userObjectID = 2 and Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<ProductDTO> getWomenList() {
        String sql = "SELECT * FROM Product WHERE userObjectID = 2 and Hot = 1 and Product_Status = 1";
        List<ProductDTO> list = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    ProductDTO p = new ProductDTO(rs.getInt("ProductID"),
                            rs.getInt("BrandID"),
                            rs.getInt("userObjectID"),
                            rs.getFloat("size"),
                            rs.getString("Name"),
                            rs.getFloat("Price"),
                            rs.getString("Color"),
                            rs.getString("Avatar"),
                            rs.getInt("Stock"),
                            rs.getBoolean("Hot"),
                            rs.getString("Detail"),
                            rs.getFloat("Sale"),
                            rs.getBoolean("Product_Status"));
                    list.add(p);
                }
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    public String getBrandName(int id){
        String name=null;
        String sql = "select * from Brand where BrandID=?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
         try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                rs = ps.executeQuery();
                while (rs.next()) {
                     name = rs.getString("BrandName");
                }
            }
        } catch (Exception e) {
        }
         return name;
    }

    public static void main(String[] args) throws ClassNotFoundException {
        ProductDAO p = new ProductDAO();
//        int[] brand = {1,2};
        Code c = p.ApplyCode("SUMMER2024");
        System.out.println(c);
    }
}
