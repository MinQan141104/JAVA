/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import sample.utils.DBUtils;

/**
 *
 * @author Luu Minh Quan
 */
public class UserDAO {

    public int userAfter(UserDTO userInput, UserDTO user, List<UserDTO> allUser) {
        int check = 1;

        //phone authentication
        if (!userInput.getPhone().isEmpty()) {
            String phoneRegex = "0\\d{9}";
            Pattern pattern = Pattern.compile(phoneRegex);
            Matcher matcher = pattern.matcher(userInput.getPhone());
            if (!matcher.matches()) {
                return 0;
            }

            user.setPhone(userInput.getPhone());
        }

        //username authentication
        if (!userInput.getUserName().isEmpty()) {
            for (UserDTO userDuplicate : allUser) {
                if (userInput.getUserName().equals(userDuplicate.getUserName())) {
                    if (!userInput.getUserName().equals(user.getUserName())) {
                        return 0;
                    }
                }
            }
            user.setUserName(userInput.getUserName());
        }

        if (!userInput.getFullName().isEmpty()) {
            user.setFullName(userInput.getFullName());
        }

        if (!userInput.getPass().isEmpty()) {
            user.setPass(userInput.getPass());
        }

        if (!userInput.getStreet().isEmpty()) {
            user.setStreet(userInput.getStreet());
        }

        if (!userInput.getDistrict().isEmpty()) {
            user.setDistrict(userInput.getDistrict());
        }

//City authentication
        if (!userInput.getCity().isEmpty()) {
            String CITY_REGEX = "^[a-zA-Z ]+$";
            Pattern pattern = Pattern.compile(CITY_REGEX);
            Matcher matcher = pattern.matcher(userInput.getCity());
            if (!matcher.matches()) {
                return 0;
            }
            user.setCity(userInput.getCity());
        }

        if (!userInput.getSex().isEmpty()) {
            user.setSex(userInput.getSex());
        }

        //email authentication
        if (!userInput.getEmail().isEmpty()) {
            String EMAIL_REGEX = "^[a-zA-Z][a-zA-Z0-9]+@[a-zA-Z]+(\\.[a-zA-Z]+){1,3}$";
            Pattern pattern = Pattern.compile(EMAIL_REGEX);
            Matcher matcher = pattern.matcher(userInput.getEmail());
            if (!matcher.matches()) {
                return 0;
            }
            for (UserDTO userDuplicate : allUser) {
                if (userInput.getEmail().equals(userDuplicate.getEmail())) {
                    if (!userInput.getEmail().equals(user.getEmail())) {
                        return 0;
                    }
                }
            }
            user.setEmail(userInput.getEmail());
        }

        if (userInput.getBirth() != null) {
            user.setBirth(userInput.getBirth());
        }

        return check;
    }

    public UserDTO insertUser(String name, String pass, String confirm, String email) {
        UserDTO user = null;

        //password authentication
        if (!pass.equals(confirm)) {
            return null;
        }

        //email authentication
        String EMAIL_REGEX = "^[a-zA-Z][a-zA-Z0-9]+@[a-zA-Z]+(\\.[a-zA-Z]+){1,3}$";
        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        Matcher matcher = pattern.matcher(email);
        if (!matcher.matches()) {
            return null;
        }

        String sql = "INSERT INTO [User] (userName, email ,userPass) "
                + "VALUES (?, ?,?)";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, pass);
                user = new UserDTO(name, pass, email);
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

    public UserDTO checkLogin(String username, String pass) throws SQLException {
        String sql = "SELECT * FROM [User] WHERE (userName = ? OR email= ?) AND userPass = ?";
        UserDTO u = null;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, username);
                ps.setString(2, username);
                ps.setString(3, pass);
//                ps.setInt(3, role);
                rs = ps.executeQuery();
                if (rs.next()) {
                    u = new UserDTO(rs.getInt("userID"),
                            rs.getString("fullName"),
                            rs.getString("userName"),
                            rs.getString("userPass"),
                            rs.getString("phoneNumber"),
                            rs.getString("Street"),
                            rs.getString("District"),
                            rs.getString("City"),
                            rs.getString("Sex"),
                            rs.getString("email"),
                            rs.getDate("birth"),
                            rs.getBoolean("isActive"),
                            rs.getBoolean("userRole"));
                }
            }
        } catch (Exception e) {
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return u;
    }

    public List<UserDTO> getAllUser() {
        List<UserDTO> userList = new ArrayList<>();
        String sql = "SELECT * FROM [User]";
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                int userId = rs.getInt("userID");
                String fullName = rs.getString("fullName");
                String userName = rs.getString("userName");
                String userPass = rs.getString("userPass");
                String phoneNumber = rs.getString("phoneNumber");
                String Sex = rs.getString("Sex");
                String email = rs.getString("email");
                java.sql.Date birth = rs.getDate("birth");
                String Street = rs.getString("Street");
                String District = rs.getString("District");
                String City = rs.getString("City");

                UserDTO user = new UserDTO(userId, fullName, userName, userPass, phoneNumber, Street, District, City, Sex, email, birth);
                userList.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userList;
    }

    public int userAfterUpdate(UserDTO user) {
        int check = 0;
        String sql = "update [user] \n"
                + "set fullName= ?, userName=?, userPass=?, phoneNumber=?, Sex=?, email=?, birth=?, Street=?, District=?, City=?\n"
                + "where userID=?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                ps = conn.prepareStatement(sql);
                ps.setString(1, user.getFullName());
                ps.setString(2, user.getUserName());
                ps.setString(3, user.getPass());
                ps.setString(4, user.getPhone());
                ps.setString(5, user.getSex());
                ps.setString(6, user.getEmail());
                ps.setDate(7, (java.sql.Date) user.getBirth());
                ps.setString(8, user.getStreet());
                ps.setString(9, user.getDistrict());
                ps.setString(10, user.getCity());
                ps.setInt(11, user.getUserId());
                check = ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return check;
    }

    public static void main(String[] args) throws SQLException {
        UserDAO u = new UserDAO();
        System.out.println(u.checkLogin("johndoe", "password123"));
    }
}
