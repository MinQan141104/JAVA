/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import sample.utils.DBUtils;

/**
 *
 * @author Adminb
 */
public class OrderDAO {
    public static void main(String[] args) {
        OrderDAO d = new OrderDAO();
        List<OrderDTO> l = d.getAllOrder(2);
        System.out.println(l);
    }
    public List<OrderDTO> getAllOrder(int userID){
        List<OrderDTO> orderList = new ArrayList<>();
        Connection con=null;
        String sql ="select * from [Order] where UserID =? ";
        try{
            con = DBUtils.getConnection();
            if(con!=null){
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setInt(1, userID);
                ResultSet rs = stm.executeQuery();
                    while(rs.next()){
                         int orderID = rs.getInt("OrderID");
        String fullName = rs.getString("fullName");
        String phoneNumber = rs.getString("phoneNumber");
        String email = rs.getString("email");
        String street = rs.getString("Street");
        String district = rs.getString("District");
        String city = rs.getString("City");
        int paymentMethodID = rs.getInt("PaymentMethodID");
        int shippingMethodID = rs.getInt("ShippingMethodID");
        double totalPrice = rs.getDouble("totalPrice");
        String orderStatus = rs.getString("order_Status");
        OrderDTO order = new OrderDTO(orderID, userID, fullName, phoneNumber, email, street, district, city, paymentMethodID, shippingMethodID, totalPrice,orderStatus);
        orderList.add(order);
                        
                    }
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return orderList;
    }
        
    public List<OrderItemDTO> getAllItemInOrder(int orderID){
        List<OrderItemDTO> itemList = new ArrayList<>();
        Connection con=null;
        String sql ="select * from OrderDetail where OrderID=? ";
        try{
            con = DBUtils.getConnection();
            if(con!=null){
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setInt(1, orderID);
                ResultSet rs = stm.executeQuery();
                    while(rs.next()){
                        int orderDetailID = rs.getInt("OrderDetail_ID");
                        int productID = rs.getInt("ProductID");
                        int quantity = rs.getInt("quantity");
                        double unitPrice = rs.getDouble("unitPrice");
                        double afterSalePrice = rs.getDouble("afterSalePrice");
                        
                        OrderItemDTO orderItem = new OrderItemDTO(orderDetailID, productID, orderID, quantity, unitPrice, afterSalePrice);
                        itemList.add(orderItem);
                    }
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return itemList;
    }
    
    public List<OrderDTO> getAllOrderWithUserID(int userID, int orderIDinput){
        List<OrderDTO> orderList = new ArrayList<>();
        Connection con=null;
        String sql ="select * from [Order] where UserID =? and OrderID=?";
        try{
            con = DBUtils.getConnection();
            if(con!=null){
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setInt(1, userID);
                stm.setInt(2, orderIDinput);
                ResultSet rs = stm.executeQuery();
                    while(rs.next()){
                         int orderID = rs.getInt("OrderID");
        String fullName = rs.getString("fullName");
        String phoneNumber = rs.getString("phoneNumber");
        String email = rs.getString("email");
        String street = rs.getString("Street");
        String district = rs.getString("District");
        String city = rs.getString("City");
        int paymentMethodID = rs.getInt("PaymentMethodID");
        int shippingMethodID = rs.getInt("ShippingMethodID");
        double totalPrice = rs.getDouble("totalPrice");
        String orderStatus = rs.getString("order_Status");
        OrderDTO order = new OrderDTO(orderID, userID, fullName, phoneNumber, email, street, district, city, paymentMethodID, shippingMethodID, totalPrice,orderStatus);
        orderList.add(order);
                        
                    }
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return orderList;
    }
    
    
}
