/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Luu Minh Quan
 */
public class ProductDTO {
    private int productId;
    private int brandId;
    private int uoId;
    private float size;
    private String name;
    private float price;
    private String color;
    private String img;
    private int stock;
    private boolean hot;
    private String description;
    private float sale;
    private boolean status;

    public ProductDTO(int productId, int brandId, int uoId, float size, String name, float price, String color, String img, int stock, boolean hot, String description, float sale, boolean status) {
        this.productId = productId;
        this.brandId = brandId;
        this.uoId = uoId;
        this.size = size;
        this.name = name;
        this.price = price;
        this.color = color;
        this.img = img;
        this.stock = stock;
        this.hot = hot;
        this.description = description;
        this.sale = sale;
        this.status = status;
    }


    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getBrandId() {
        return brandId;
    }

    public void setBrandId(int brandId) {
        this.brandId = brandId;
    }

    public int getUoId() {
        return uoId;
    }

    public void setUoId(int uoId) {
        this.uoId = uoId;
    }

    public boolean isHot() {
        return hot;
    }

    public void setHot(boolean hot) {
        this.hot = hot;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getSale() {
        return sale;
    }

    public void setSale(float sale) {
        this.sale = sale;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    @Override
    public String toString() {
        return "ProductDTO{" + "productId=" + productId + ", brandId=" + brandId + ", uoId=" + uoId + ", size=" + size + ", name=" + name + ", price=" + price + ", color=" + color + ", img=" + img + ", stock=" + stock + ", hot=" + hot + ", description=" + description + ", sale=" + sale + ", status=" + status + '}';
    }
    
       
}
