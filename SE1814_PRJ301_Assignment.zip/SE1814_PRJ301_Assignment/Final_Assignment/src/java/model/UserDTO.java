/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Luu Minh Quan
 */
public class UserDTO {

    private int userId;
    private String fullName;
    private String userName;
    private String pass;
    private String phone;
    private String street;
    private String district;
    private String city;
    private String sex;
    private String email;
    private Date birth;
    private boolean Active;
    private boolean uRole;
    private Date createdAt;

    public UserDTO() {
    }

    public UserDTO(int userId, String fullName, String userName, String pass, String phone, String street, String district, String city, String sex, String email, Date birth, boolean Active, boolean uRole) {
        this.userId = userId;
        this.fullName = fullName;
        this.userName = userName;
        this.pass = pass;
        this.phone = phone;
        this.street = street;
        this.district = district;
        this.city = city;
        this.sex = sex;
        this.email = email;
        this.birth = birth;
        this.Active = Active;
        this.uRole = uRole;
    }

    public UserDTO(int userId, String fullName, String userName, String pass, String phone, String street, String district, String city, String sex, String email, Date birth, boolean Active, boolean uRole, Date createdAt) {
        this.userId = userId;
        this.fullName = fullName;
        this.userName = userName;
        this.pass = pass;
        this.phone = phone;
        this.street = street;
        this.district = district;
        this.city = city;
        this.sex = sex;
        this.email = email;
        this.birth = birth;
        this.Active = Active;
        this.uRole = uRole;
        this.createdAt = createdAt;
    }

    public UserDTO(int userId, String fullName, String userName, String pass, String phone, String street, String district, String city, String sex, String email, Date birth) {
        this.userId = userId;
        this.fullName = fullName;
        this.userName = userName;
        this.pass = pass;
        this.phone = phone;
        this.street = street;
        this.district = district;
        this.city = city;
        this.sex = sex;
        this.email = email;
        this.birth = birth;
    }

    public UserDTO(String name, String pass, String email) {
       this.userName = name;
       this.pass = pass;
       this.email = email;
    }
    
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public boolean isActive() {
        return Active;
    }

    public void setActive(boolean Active) {
        this.Active = Active;
    }

    public boolean isuRole() {
        return uRole;
    }

    public void setuRole(boolean uRole) {
        this.uRole = uRole;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "UserDTO{" + "userId=" + userId + ", fullName=" + fullName + ", userName=" + userName + ", pass=" + pass + ", phone=" + phone + ", address=" + street + district + city + ", sex=" + sex + ", email=" + email + ", birth=" + birth + ", Active=" + Active + ", uRole=" + uRole + '}';
    }
    
}
