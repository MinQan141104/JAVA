/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Luu Minh Quan
 */
public class Code {
    private String code;
    private String detail;
    private double discountAmount;
    private String startDate;
    private String endDate;
    private int quantity;

    public Code(String code, String detail, double discountAmount, String startDate, String endDate, int quantity) {
        this.code = code;
        this.detail = detail;
        this.discountAmount = discountAmount;
        this.startDate = startDate;
        this.endDate = endDate;
        this.quantity = quantity;
    }

    
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Code{" + "code=" + code + ", detail=" + detail + ", discountAmount=" + discountAmount + ", startDate=" + startDate + ", endDate=" + endDate + ", quantity=" + quantity + '}';
    }
    
}
