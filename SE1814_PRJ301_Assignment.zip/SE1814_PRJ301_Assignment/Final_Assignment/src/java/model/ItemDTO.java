/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Luu Minh Quan
 */
public class ItemDTO {

    private ProductDTO product;
    private int quantity;
    private float size;
    private double price;

    public ItemDTO(ProductDTO product, int quantity, double price, float size) {
        this.product = product;
        this.quantity = quantity;
        this.price = price;
        this.size = size;
    }

    public ItemDTO() {
    }

    public ProductDTO getProduct() {
        return product;
    }

    public void setProduct(ProductDTO product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }
 
}
