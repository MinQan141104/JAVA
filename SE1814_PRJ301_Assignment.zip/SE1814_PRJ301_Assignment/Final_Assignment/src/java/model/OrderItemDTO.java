/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Adminb
 */
public class OrderItemDTO {
    private int orderDetailID;
    private int productID;
    private int orderID;
    private int quantity;
    private double unitPrice;
    private double afterSalePrice;

    public OrderItemDTO() {}
    

    public OrderItemDTO(int orderDetailID,int productID, int orderID, int quantity, double unitPrice, double afterSalePrice) {
        this.orderDetailID = orderDetailID;
        this.productID = productID;
        this.orderID = orderID;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.afterSalePrice = afterSalePrice;
    }

    // Getters and Setters for all fields

    public int getOrderDetailID() {
        return orderDetailID;
    }

    public void setOrderDetailID(int orderDetailID) {
        this.orderDetailID = orderDetailID;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public double getAfterSalePrice() {
        return afterSalePrice;
    }

    public void setAfterSalePrice(double afterSalePrice) {
        this.afterSalePrice = afterSalePrice;
    }

    @Override
    public String toString() {
        return "OrderItemDTO{" + "orderDetailID=" + orderDetailID + ", productID=" + productID + ", orderID=" + orderID + ", quantity=" + quantity + ", unitPrice=" + unitPrice + ", afterSalePrice=" + afterSalePrice + '}';
    }

    
}
