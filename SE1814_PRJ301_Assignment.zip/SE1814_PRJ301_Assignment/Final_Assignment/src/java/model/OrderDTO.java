/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Adminb
 */
public class OrderDTO {
     private int orderID;
    private int userID;
    private String fullName;
    private String phoneNumber;
    private String email;
    private String street;
    private String district;
    private String city;
    private int paymentMethodID;
    private int shippingMethodID;
    private double totalPrice;
    private String orderStatus;

    public OrderDTO() {}

    public OrderDTO(int orderID, int userID, String fullName, String phoneNumber, String email, String street, String district, String city, int paymentMethodID, int shippingMethodID, double totalPrice) {
        this.orderID = orderID;
        this.userID = userID;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.street = street;
        this.district = district;
        this.city = city;
        this.paymentMethodID = paymentMethodID;
        this.shippingMethodID = shippingMethodID;
        this.totalPrice = totalPrice;
    }
    
    

    public OrderDTO(int orderID,int userID, String fullName, String phoneNumber, String email, String street, String district, String city, int paymentMethodID, int shippingMethodID, double totalPrice,
                 String orderStatus) {
        this.orderID = orderID;
        this.userID = userID;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.street = street;
        this.district = district;
        this.city = city;
        this.paymentMethodID = paymentMethodID;
        this.shippingMethodID = shippingMethodID;
        this.totalPrice = totalPrice;
        this.orderStatus = orderStatus;
    }

    // Getters and Setters for all fields

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPaymentMethodID() {
        return paymentMethodID;
    }

    public void setPaymentMethodID(int paymentMethodID) {
        this.paymentMethodID = paymentMethodID;
    }

    public int getShippingMethodID() {
        return shippingMethodID;
    }

    public void setShippingMethodID(int shippingMethodID) {
        this.shippingMethodID = shippingMethodID;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    @Override
    public String toString() {
        return "OrderDTO{" + "orderID=" + orderID + ", userID=" + userID + ", fullName=" + fullName + ", phoneNumber=" + phoneNumber + ", email=" + email + ", street=" + street + ", district=" + district + ", city=" + city + ", paymentMethodID=" + paymentMethodID + ", shippingMethodID=" + shippingMethodID + ", totalPrice=" + totalPrice + ", orderStatus=" + orderStatus + '}';
    }
    
    
}
