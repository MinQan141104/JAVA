﻿
create database ASSIGNMENT
go
use ASSIGNMENT
go
-- Create the User table
CREATE TABLE [User] (
    userID INT IDENTITY(1,1) PRIMARY KEY ,
	fullName VARCHAR(50),
    userName VARCHAR(50),
	userPass VARCHAR(50),
    phoneNumber VARCHAR(20),
    Sex NVARCHAR(10),
    email VARCHAR(100),
    birth DATE,
    Street NVARCHAR(50),
	District NVARCHAR(50),
	City  NVARCHAR(50),
    isActive BIT DEFAULT 1,
    userRole bit default 0,
	createdAt DATETIME DEFAULT GETDATE()
);
go
-- Insert
-- Chèn người dùng 
INSERT INTO [User] (fullName, userName, userPass, phoneNumber, Sex, email, birth, Street, District, City, userRole )
VALUES
('admin', 'admin', '123', '123-456-7890', 'Male', 'john.doe@example.com', '1980-01-01', '123 Main St', 'Downtown', 'Metropolis',1),
('John Doe', 'johndoe', 'password123', '0935786524', 'Male', 'john.doe@example.com', '1980-01-01', '123 Main St', 'Downtown', 'Metropolis',0),
('Jane Smith', 'janesmith', 'securepass', '0985246852', 'Female', 'jane.smith@example.com', '1990-05-15', '456 Elm St', 'Uptown', 'Smallville',0),
('Sam Wilson', 'samwilson', 'mypassword', '0368456878', 'Non-binary', 'sam.wilson@example.com', '2000-12-25', '789 Oak St', 'Midtown', 'Bigcity',0);

go
-- Create the Categories table
CREATE TABLE Brand (
    BrandID INT IDENTITY(1,1) PRIMARY KEY,
    BrandName VARCHAR(50),
);
go
-- Insert
INSERT INTO Brand VALUES 
('Nike'),
('Adidas'),
('Puma')
go
-- Create the userObject table
CREATE TABLE userObject (
    userObjectID INT IDENTITY(1,1) PRIMARY KEY,
    userObjectName VARCHAR(50),
    detail NVARCHAR(300),
);
go
-- Insert

-- Chèn danh mục giày cho nam
INSERT INTO userObject (userObjectName, detail) 
VALUES ('Men Shoes', 'Footwear products for men');

-- Chèn danh mục giày cho nữ
INSERT INTO userObject (userObjectName, detail) 
VALUES ('Women Shoes', 'Footwear products for women');

-- Chèn danh mục giày cho trẻ em
INSERT INTO userObject (userObjectName, detail) 
VALUES ('Kids Shoes', 'Footwear products for children');

go

go
-- Create the Product table
CREATE TABLE Product (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
	BrandID int,
	userObjectID int, 
    Detail NVARCHAR(MAX),
    Hot BIT default 0,
	Name NVARCHAR(100),
    Avatar NVARCHAR(MAX),
    Price DECIMAL(18, 2),
	Color VARCHAR(20),
	Size float,
	Stock INT,
	Sale float default 0,
    Product_Status bit default 1,
	FOREIGN KEY (BrandID) REFERENCES Brand(BrandID),
	FOREIGN KEY (userObjectID) REFERENCES userObject(userObjectID)
);
go
-- INSERT
-- Chèn dữ liệu vào bảng Product
INSERT INTO Product (userObjectID, BrandID, Detail, Hot, Name, Avatar, Price, Color, Size, Stock, Sale)
VALUES 
(1, 2,'Share your Inter Miami CF pride on and off the futsal court. These adidas Samba football boots show off the clubs vibrant third kit colours and its crest. Wherever you take them, these limited-collection shoes will keep you comfortable with a leather upper, complete with classic suede toe, and a grippy rubber outsole.',
1, 'SAMBA INTER MIAMI CF INDOOR BOOTS','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/ccd33426290f4b0788f48124005ab2f9_9366/Giay_DJa_Bong_Trong_Nha_Samba_Inter_Miami_CF_trang_IH8160_01_standard.jpg',
108, 'White', 8.0, 10, 0.15),
(2, 1,'Responsive cushioning in the Pegasus provides an energised ride for everyday road running. Experience lighter-weight energy return with dual Air Zoom units and a ReactX foam midsole. Plus, improved engineered mesh on the upper decreases weight and increases breathability.',
1, 'Nike Pegasus 41','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/0558cdb5-4d42-4f4d-9b37-5038f1f97f9f/pegasus-41-road-running-shoes-RZm89S.png',
219, 'Blue', 7.0, 10, 0.10),
(3, 2,'The bow and the three stripes are back! No matter who and how different you are, Hello Kitty knows what friendship is all about. Follow Hello Kitty and Friends through a unique and unexpected lens that ties into adidas Originals history: time for Hello Kitty together with My Melody and Kuromi to inspire smiles and carry a world of happiness through iconic Music references such as Hip Hop and Street.',
1, 'ADIDAS ORIGINALS X HELLO KITTY AND FRIENDS STAN SMITH SHOES',
'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dba238ac016c434295bf87d1b67e8834_9366/adidas_Originals_x_Hello_Kitty_and_Friends_Stan_Smith_Shoes_White_IG8407_01_standard.jpg',
80, 'White', 3, 10, 0.20)
,(2, 2,'The adidas Superstar shoes are entering the metaverse, thanks to this unique expression of the shell-toe silhouette. This chunky, slip-on version is built with foam material made in part from sugarcane, to create a one-of-a-kind design. Step at once into the forefront of sustainability and the future of fashion.',
1, 'SUPERSTAR ADIFOM','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/15efd399b216463e9392af5700c52792_9366/Giay_Superstar_Adifom_trang_HQ8750_01_standard.jpg',
174, 'White', 6.5, 10, 0.3)
,(2, 2,'Australian fashion label Song for the Mute is known for their unique approach and philosophy towards design. We see the fashion brands elevated eye in our collaboration on these adidas Shadowturf shoes. And then what you feel is comfort, since Adiprene cushioning delivers it all day long. Soft, fluid and with a sense of oddity, these trainers fit seamlessly into your day to day, as if theyve always been a part of it.',
1, 'SHADOWTURF SFTM SHOES','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/8ee33fece1a04faea400aead00ec44d2_9366/Shadowturf_SFTM_Shoes_White_GY7017_01_standard.jpg',
265, 'Milk Coffee', 9.5, 10, 0),
(2, 3, 'The PUMA Velocity NITRO™ 3 – with this shoe, were taking industry-best and bringing it to you. These kicks are all about speed and comfort thanks to advanced NITRO technology, offering superior responsiveness and cushioning in a lightweight package that feels like youre running on clouds. Plus, with the heel spoiler, you not only get a sleek look but youll also benefit from enhanced stability for confident strides. Get ready to up your running game with the Velocity NITRO™ 3. Its not just a shoe; its a statement.',
1, 'Velocity NITRO™ 3 Womens Running Shoes','https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/309702/01/sv01/fnd/PNA/fmt/png/Velocity-NITRO''-''3-Women''s-Running-Shoes',
130, 'Black Orange', 8, 10, 0),
(2, 1,'The fast break style of 80s basketball meets the fast-paced culture of todays game with the Nike Court Vision Low. The upper is inspired by old-school basketball sneakers, while the classic rubber cupsole has featured on some of the most iconic kicks of the past.',
1, 'Air Jordan 11 Retro Low "Legend Pink"','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/84396dfc-673a-48a4-a968-37b9a934451f/air-jordan-11-retro-low-legend-pink-shoes-M3mj4q.png',
279, 'White Pink', 10, 10, 0.1),
(3, 3,'Mesh upper for breathability
Extended lacing for secure fit and midsole lockdown
TPU shank at midsole provides support and motion control
EVA heel pod for stable cushioning
Rubber outsole for durable grip and traction
PUMA branded elastic heel strap
Embroidered PUMA Cat Logo at lateral toe
Webbing pull loop at heel and tongue',
1, 'Axelion Mesh Little Kids'' Shoes','https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/194286/01/sv01/fnd/PNA/fmt/png/Axelion-Mesh-Little-Kids''-Shoes',
90, 'Black', 6, 10, 0.3),
(1, 3, 'Exciting details with graphics on the back of the tongue and along the sockliners, extra details as the double laces to style it your way and a premium shoe box with the image of the Art Car on the lid, a plastic case lying on top of the sneakers which allows you to keep and admire this masterpiece. BMW logo pin on the heel and woven label on the lateral side, PUMA logo embroidered on the tongue, and number 93 debossed on the medial of the shoe.',
1, 'PUMA x BMW M MOTORSPORT Suede Calder Men''s Sneakers','https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/308184/01/sv01/fnd/PNA/fmt/png/PUMA-x-BMW-M-MOTORSPORT-Suede-Calder-Men''s-Sneakers',
110, 'Red', 8.5, 10, 0),
(1, 1,'The full-grain and synthetic leathers in the upper make for a durable shoe.
Free-floating eyestays at the ankle pull down over your foot when you lace up.
Nike Air technology absorbs impact for cushioning with every step.
Rubber in the outsole gives you everyday traction.
Colour Shown: White/White/Neutral Grey/Oxidised Green
Style: FQ8138-103
Country/Region of Origin: China',
1, 'Air Jordan 4 Retro "Oxidised Green"','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c0604e24-0b81-43f7-9288-73b8274dda45/air-jordan-4-retro-oxidised-green-shoes-lw9R0z.png',
305, 'White', 10, 10, 0.15),
(1, 1, 'Step into a classic. This AJ4 throws it back with full-grain leather and premium textiles. Iconic design elements from the original, like floating eyestays and mesh-inspired accents, feel just as fresh as they did in 89.',
1, 'Nike Court Vision Low','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/d4776188-7104-419e-a1c8-f055737b9e6e/court-vision-low-next-nature-shoes-N2fFHb.png',
89, 'White', 7.5, 10, 0),
(3, 2,'The superpowers of Marvel''s Spider-Man meet the classic cool of the adidas Grand Court style to create kids shoes from adidas that will have them flying all day long. With the iconic blue and red colours of one of Marvel''s most beloved Super Heroes, and Spider-Man''s masked face adorning the sides, little ones can tap into his speed, agility and wit',
1, 'MARVEL''S SPIDER-MAN GRAND COURT SHOES KIDS','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/73f262e17ca94a6fbb9b209a7804b5f1_9366/Marvels_Spider-Man_Grand_Court_Shoes_Kids_White_IF0925_01_standard.jpg',
60, 'White', 5, 10, 0),
(3, 2,'The game''s all about goals, and these football boots are crafted to find the net. Every. Time. Target perfection in all-new adidas Predator. Covered in a 3D texture and featuring grippy Strikescale fins on its medial side, the Hybridfeel upper on these juniors'' boots is optimised for accurate shooting. Down below, a lug rubber outsole offers stability on artificial turf courts.',
1, 'PREDATOR 24 LEAGUE TURF BOOTS','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dc6df6caf6fb4594a18d622cecd0ea13_9366/Predator_24_League_Turf_Boots_Yellow_IG5444_01_standard_hover.jpg',
75, 'Yellow', 4, 10, 0.1),
(3, 1,'Benefits
The hook-and-loop closure system makes on and off easy.
Heel pull assists in getting shoes on little feet.
Rubber outsoles give your little one ample traction.',
1, 'Jordan 1 Low Alt','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/16be7614-82eb-4202-b2d1-3a8d2194a529/jordan-1-low-alt-younger-shoes-W8Wbv0.png',
99, 'Black White', 3, 10, 0),
(1, 1,'The Nike MC Trainer 2 can help you shift from circuit training in the weight room to the Astroturf for quick-twitch conditioning, seamlessly. It''s a multi-purpose power that combines versatility, stability and longevity so that you can stay locked in on the physical task at hand.',
1, 'Nike MC Trainer 2','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/2d0ff796-63fb-4728-9845-1334f57c73ea/mc-trainer-2-workout-shoes-WFVXbk.png',
105, 'Black', 9.5, 10, 0);
INSERT INTO Product (userObjectID, BrandID, Detail, Hot, Name, Avatar, Price, Color, Size, Stock, Sale)
VALUES 
(1, 2,'Share your Inter Miami CF pride on and off the futsal court. These adidas Samba football boots show off the clubs vibrant third kit colours and its crest. Wherever you take them, these limited-collection shoes will keep you comfortable with a leather upper, complete with classic suede toe, and a grippy rubber outsole.',
0, 'SAMBA INTER MIAMI CF INDOOR BOOTS','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/ccd33426290f4b0788f48124005ab2f9_9366/Giay_DJa_Bong_Trong_Nha_Samba_Inter_Miami_CF_trang_IH8160_01_standard.jpg',
108, 'White', 8.5, 10, 0.15),
(2, 1,'Responsive cushioning in the Pegasus provides an energised ride for everyday road running. Experience lighter-weight energy return with dual Air Zoom units and a ReactX foam midsole. Plus, improved engineered mesh on the upper decreases weight and increases breathability.',
0, 'Nike Pegasus 41','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/0558cdb5-4d42-4f4d-9b37-5038f1f97f9f/pegasus-41-road-running-shoes-RZm89S.png',
219, 'Blue', 8.0, 10, 0.10),
(3, 2,'The bow and the three stripes are back! No matter who and how different you are, Hello Kitty knows what friendship is all about. Follow Hello Kitty and Friends through a unique and unexpected lens that ties into adidas Originals history: time for Hello Kitty together with My Melody and Kuromi to inspire smiles and carry a world of happiness through iconic Music references such as Hip Hop and Street.',
0, 'ADIDAS ORIGINALS X HELLO KITTY AND FRIENDS STAN SMITH SHOES',
'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dba238ac016c434295bf87d1b67e8834_9366/adidas_Originals_x_Hello_Kitty_and_Friends_Stan_Smith_Shoes_White_IG8407_01_standard.jpg',
80, 'White', 4, 10, 0.20)
,(2, 2,'The adidas Superstar shoes are entering the metaverse, thanks to this unique expression of the shell-toe silhouette. This chunky, slip-on version is built with foam material made in part from sugarcane, to create a one-of-a-kind design. Step at once into the forefront of sustainability and the future of fashion.',
0, 'SUPERSTAR ADIFOM','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/15efd399b216463e9392af5700c52792_9366/Giay_Superstar_Adifom_trang_HQ8750_01_standard.jpg',
174, 'White', 6.0, 10, 0.3)
,(2, 2,'Australian fashion label Song for the Mute is known for their unique approach and philosophy towards design. We see the fashion brands elevated eye in our collaboration on these adidas Shadowturf shoes. And then what you feel is comfort, since Adiprene cushioning delivers it all day long. Soft, fluid and with a sense of oddity, these trainers fit seamlessly into your day to day, as if theyve always been a part of it.',
0, 'SHADOWTURF SFTM SHOES','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/8ee33fece1a04faea400aead00ec44d2_9366/Shadowturf_SFTM_Shoes_White_GY7017_01_standard.jpg',
265, 'Milk Coffee', 7.5, 10, 0),
(2, 3, 'The PUMA Velocity NITRO™ 3 – with this shoe, were taking industry-best and bringing it to you. These kicks are all about speed and comfort thanks to advanced NITRO technology, offering superior responsiveness and cushioning in a lightweight package that feels like youre running on clouds. Plus, with the heel spoiler, you not only get a sleek look but youll also benefit from enhanced stability for confident strides. Get ready to up your running game with the Velocity NITRO™ 3. Its not just a shoe; its a statement.',
0, 'Velocity NITRO™ 3 Womens Running Shoes','https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/309702/01/sv01/fnd/PNA/fmt/png/Velocity-NITRO''-''3-Women''s-Running-Shoes',
130, 'Black Orange', 9, 10, 0),
(2, 1,'The fast break style of 80s basketball meets the fast-paced culture of todays game with the Nike Court Vision Low. The upper is inspired by old-school basketball sneakers, while the classic rubber cupsole has featured on some of the most iconic kicks of the past.',
0, 'Air Jordan 11 Retro Low "Legend Pink"','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/84396dfc-673a-48a4-a968-37b9a934451f/air-jordan-11-retro-low-legend-pink-shoes-M3mj4q.png',
279, 'White Pink', 11, 10, 0.1),
(3, 3,'Mesh upper for breathability
Extended lacing for secure fit and midsole lockdown
TPU shank at midsole provides support and motion control
EVA heel pod for stable cushioning
Rubber outsole for durable grip and traction
PUMA branded elastic heel strap
Embroidered PUMA Cat Logo at lateral toe
Webbing pull loop at heel and tongue',
0, 'Axelion Mesh Little Kids'' Shoes','https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/194286/01/sv01/fnd/PNA/fmt/png/Axelion-Mesh-Little-Kids''-Shoes',
90, 'Black', 5, 10, 0.3),
(1, 3, 'Exciting details with graphics on the back of the tongue and along the sockliners, extra details as the double laces to style it your way and a premium shoe box with the image of the Art Car on the lid, a plastic case lying on top of the sneakers which allows you to keep and admire this masterpiece. BMW logo pin on the heel and woven label on the lateral side, PUMA logo embroidered on the tongue, and number 93 debossed on the medial of the shoe.',
0, 'PUMA x BMW M MOTORSPORT Suede Calder Men''s Sneakers','https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/308184/01/sv01/fnd/PNA/fmt/png/PUMA-x-BMW-M-MOTORSPORT-Suede-Calder-Men''s-Sneakers',
110, 'Red', 7.5, 10, 0),
(1, 1,'The full-grain and synthetic leathers in the upper make for a durable shoe.
Free-floating eyestays at the ankle pull down over your foot when you lace up.
Nike Air technology absorbs impact for cushioning with every step.
Rubber in the outsole gives you everyday traction.
Colour Shown: White/White/Neutral Grey/Oxidised Green
Style: FQ8138-103
Country/Region of Origin: China',
0, 'Air Jordan 4 Retro "Oxidised Green"','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c0604e24-0b81-43f7-9288-73b8274dda45/air-jordan-4-retro-oxidised-green-shoes-lw9R0z.png',
305, 'White', 6.5, 10, 0.15),
(1, 1, 'Step into a classic. This AJ4 throws it back with full-grain leather and premium textiles. Iconic design elements from the original, like floating eyestays and mesh-inspired accents, feel just as fresh as they did in 89.',
0, 'Nike Court Vision Low','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/d4776188-7104-419e-a1c8-f055737b9e6e/court-vision-low-next-nature-shoes-N2fFHb.png',
89, 'White', 10.5, 10, 0),
(3, 2,'The superpowers of Marvel''s Spider-Man meet the classic cool of the adidas Grand Court style to create kids shoes from adidas that will have them flying all day long. With the iconic blue and red colours of one of Marvel''s most beloved Super Heroes, and Spider-Man''s masked face adorning the sides, little ones can tap into his speed, agility and wit',
0, 'MARVEL''S SPIDER-MAN GRAND COURT SHOES KIDS','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/73f262e17ca94a6fbb9b209a7804b5f1_9366/Marvels_Spider-Man_Grand_Court_Shoes_Kids_White_IF0925_01_standard.jpg',
60, 'White', 6, 10, 0),
(3, 2,'The game''s all about goals, and these football boots are crafted to find the net. Every. Time. Target perfection in all-new adidas Predator. Covered in a 3D texture and featuring grippy Strikescale fins on its medial side, the Hybridfeel upper on these juniors'' boots is optimised for accurate shooting. Down below, a lug rubber outsole offers stability on artificial turf courts.',
0, 'PREDATOR 24 LEAGUE TURF BOOTS','https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dc6df6caf6fb4594a18d622cecd0ea13_9366/Predator_24_League_Turf_Boots_Yellow_IG5444_01_standard_hover.jpg',
75, 'Yellow', 3, 10, 0.1),
(3, 1,'Benefits
The hook-and-loop closure system makes on and off easy.
Heel pull assists in getting shoes on little feet.
Rubber outsoles give your little one ample traction.',
0, 'Jordan 1 Low Alt','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/16be7614-82eb-4202-b2d1-3a8d2194a529/jordan-1-low-alt-younger-shoes-W8Wbv0.png',
99, 'Black White', 5, 10, 0),
(1, 2,'The Nike MC Trainer 2 can help you shift from circuit training in the weight room to the Astroturf for quick-twitch conditioning, seamlessly. It''s a multi-purpose power that combines versatility, stability and longevity so that you can stay locked in on the physical task at hand.',
0, 'Nike MC Trainer 2','https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/2d0ff796-63fb-4728-9845-1334f57c73ea/mc-trainer-2-workout-shoes-WFVXbk.png',
105, 'Black', 8.0, 10, 0);
go

CREATE TABLE Wishlist (
    WishlistId INT PRIMARY KEY identity(1,1),
	userID INT,
	ProductID int,
    createdAt DATETIME default getdate(),
    FOREIGN KEY (userID) REFERENCES [User](userId),
	FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);
go
--INSERT

CREATE TABLE Product_Images (
    id INT PRIMARY KEY IDENTITY(1,1),
    ProductID INT,
    path VARCHAR(MAX) NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);
INSERT INTO Product_Images VALUES
(1, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/ccd33426290f4b0788f48124005ab2f9_9366/Samba_Inter_Miami_CF_Indoor_Boots_White_IH8160_01_standard.jpg'),
(1, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/66bca59da51b402d95e38dab7d4ced7f_9366/Samba_Inter_Miami_CF_Indoor_Boots_White_IH8160_22_model.jpg'),
(1, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/2560832bcaa64aa59adda90fa5775884_9366/Samba_Inter_Miami_CF_Indoor_Boots_White_IH8160_02_standard.jpg'),
(1, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4af41927339c4b04890fe9a660a8d8ed_9366/Samba_Inter_Miami_CF_Indoor_Boots_White_IH8160_03_standard.jpg'),
(2, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/0558cdb5-4d42-4f4d-9b37-5038f1f97f9f/pegasus-41-road-running-shoes-RZm89S.png'),
(2, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/838b3043-7a43-44d3-9e17-7ee6cf3f19d4/pegasus-41-road-running-shoes-RZm89S.png'),
(2, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/95e183c1-65d6-48b8-9992-ed266dcf5b53/pegasus-41-road-running-shoes-RZm89S.png'),
(2, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/82b72c0c-121e-4330-abfc-bc2b4f375aa4/pegasus-41-road-running-shoes-RZm89S.png'),
(3, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dba238ac016c434295bf87d1b67e8834_9366/adidas_Originals_x_Hello_Kitty_and_Friends_Stan_Smith_Shoes_White_IG8407_01_standard.jpg'),
(3, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/9dc7623c10ea4db8972e105c92bf9f5d_9366/adidas_Originals_x_Hello_Kitty_and_Friends_Stan_Smith_Shoes_White_IG8407_02_standard.jpg'),
(3, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/9934cb44643541b18f3830a45b6f8392_9366/adidas_Originals_x_Hello_Kitty_and_Friends_Stan_Smith_Shoes_White_IG8407_04_standard.jpg'),
(3, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/cf46b3752b6b44999fdbb978c0336b0d_9366/adidas_Originals_x_Hello_Kitty_and_Friends_Stan_Smith_Shoes_White_IG8407_03_standard.jpg'),
(4, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/15efd399b216463e9392af5700c52792_9366/Adifom_Superstar_Shoes_White_HQ8750_01_standard.jpg'),
(4, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/9b8ee6de166747e3bad2af5700c53045_9366/Adifom_Superstar_Shoes_White_HQ8750_02_standard_hover.jpg'),
(4, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4ebab9221be0451db38faf5700c53844_9366/Adifom_Superstar_Shoes_White_HQ8750_03_standard.jpg'),
(4, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/6d4b0d88cc414baea3e7af5700c54174_9366/Adifom_Superstar_Shoes_White_HQ8750_04_standard.jpg'),
(5, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/8ee33fece1a04faea400aead00ec44d2_9366/Shadowturf_SFTM_Shoes_White_GY7017_01_standard.jpg'),
(5, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/813aaae87c764353943faead00ec5878_9366/Shadowturf_SFTM_Shoes_White_GY7017_02_standard_hover.jpg'),
(5, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/3eb5175c5e4c4afe9b1eaead00ec6493_9366/Shadowturf_SFTM_Shoes_White_GY7017_03_standard.jpg'),
(5, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/7491919d4b6643a5ab3baead00ec6fe5_9366/Shadowturf_SFTM_Shoes_White_GY7017_04_standard.jpg'),
(6, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/309702/01/fnd/PNA/fmt/png/Velocity-NITRO''-''3-Women''s-Running-Shoes'),
(6, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/309702/01/sv02/fnd/PNA/fmt/png/Velocity-NITRO''-''3-Women''s-Running-Shoes'),
(6, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/309702/01/sv04/fnd/PNA/fmt/png/Velocity-NITRO''-''3-Women''s-Running-Shoes'),
(6, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/309702/01/mod01/fnd/PNA/fmt/png/Velocity-NITRO''-''3-Women''s-Running-Shoes'),
(7, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/84396dfc-673a-48a4-a968-37b9a934451f/air-jordan-11-retro-low-legend-pink-shoes-M3mj4q.png'),
(7, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/546bd9ba-6ddd-4743-b244-5c912df1ccac/air-jordan-11-retro-low-legend-pink-shoes-M3mj4q.png'),
(7, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/d89db66b-2c36-4755-9382-b928a5b3c808/air-jordan-11-retro-low-legend-pink-shoes-M3mj4q.png'),
(7, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/f2425f1b-b4a4-4ae2-b4d4-6f8a78d7cdc9/air-jordan-11-retro-low-legend-pink-shoes-M3mj4q.png'),
(8, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/194286/01/sv01/fnd/PNA/fmt/png/Axelion-Mesh-Little-Kids''-Shoes'),
(8, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/194286/01/fnd/PNA/fmt/png/Axelion-Mesh-Little-Kids''-Shoes'),
(8, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/194286/01/bv/fnd/PNA/fmt/png/Axelion-Mesh-Little-Kids''-Shoes'),
(8, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_2000,h_2000/global/194286/01/sv04/fnd/PNA/fmt/png/Axelion-Mesh-Little-Kids''-Shoes'),
(9, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/308184/01/sv01/fnd/PNA/fmt/png/PUMA-x-BMW-M-MOTORSPORT-Suede-Calder-Men''s-Sneakers'),
(9, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/308184/01/fnd/PNA/fmt/png/PUMA-x-BMW-M-MOTORSPORT-Suede-Calder-Men''s-Sneakers'),
(9, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/308184/01/sv02/fnd/PNA/fmt/png/PUMA-x-BMW-M-MOTORSPORT-Suede-Calder-Men''s-Sneakers'),
(9, 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_900,h_900/global/308184/01/sv04/fnd/PNA/fmt/png/PUMA-x-BMW-M-MOTORSPORT-Suede-Calder-Men''s-Sneakers'),
(10, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/c0604e24-0b81-43f7-9288-73b8274dda45/air-jordan-4-retro-oxidised-green-shoes-lw9R0z.png'),
(10, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/935827cd-f5f7-40a9-a6a0-bb902a10cbf2/air-jordan-4-retro-oxidised-green-shoes-lw9R0z.png'),
(10, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/dd814f19-8267-4663-acee-42b61a874646/air-jordan-4-retro-oxidised-green-shoes-lw9R0z.png'),
(10, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/3a03ff93-aa54-4967-855d-70971d6c58a4/air-jordan-4-retro-oxidised-green-shoes-lw9R0z.png'),
(11, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/d4776188-7104-419e-a1c8-f055737b9e6e/court-vision-low-next-nature-shoes-N2fFHb.png'),
(11, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/8c75f88c-968f-424c-9286-5c668336fed8/court-vision-low-next-nature-shoes-N2fFHb.png'),
(11, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/a0aae2ee-c89e-4eb2-a1b2-3644e6a10828/court-vision-low-next-nature-shoes-N2fFHb.png'),
(11, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/e9776563-0cf2-432e-94e2-eb5159dd4a57/court-vision-low-next-nature-shoes-N2fFHb.png'),
(12, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/73f262e17ca94a6fbb9b209a7804b5f1_9366/Marvels_Spider-Man_Grand_Court_Shoes_Kids_White_IF0925_01_standard.jpg'),
(12, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/7c75e09b885940e3a3be2eeff26690e3_9366/Marvels_Spider-Man_Grand_Court_Shoes_Kids_White_IF0925_02_standard_hover.jpg'),
(12, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4c4306b1bfcf455c9cf619d78eda8f0f_9366/Marvels_Spider-Man_Grand_Court_Shoes_Kids_White_IF0925_04_standard.jpg'),
(12, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/c10361cf25f64b608bda28f9e30961cf_9366/Marvels_Spider-Man_Grand_Court_Shoes_Kids_White_IF0925_41_detail.jpg'),
(13, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/dc6df6caf6fb4594a18d622cecd0ea13_9366/Predator_24_League_Turf_Boots_Yellow_IG5444_01_standard_hover.jpg'),
(13, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/a052a425fe07418890fe90c1bfd433f4_9366/Predator_24_League_Turf_Boots_Yellow_IG5444_22_model.jpg'),
(13, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/c314f6cb3093455e98f40f55e5107fd9_9366/Predator_24_League_Turf_Boots_Yellow_IG5444_02_standard.jpg'),
(13, 'https://assets.adidas.com/images/h_840,f_auto,q_auto,fl_lossy,c_fill,g_auto/4a1f8fdf5b2a44b4b847478d43fec53c_9366/Predator_24_League_Turf_Boots_Yellow_IG5444_04_standard.jpg'),
(14, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/16be7614-82eb-4202-b2d1-3a8d2194a529/jordan-1-low-alt-younger-shoes-W8Wbv0.png'),
(14, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/23ccc813-db5b-4c65-9259-9f188e309fb6/jordan-1-low-alt-younger-shoes-W8Wbv0.png'),
(14, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/6f82ba76-20c2-4969-9244-b3d74fa10c43/jordan-1-low-alt-younger-shoes-W8Wbv0.png'),
(14, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco,u_126ab356-44d8-4a06-89b4-fcdcc8df0245,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/7c0c0af7-4abc-4354-ade9-2dd0e841cec3/jordan-1-low-alt-younger-shoes-W8Wbv0.png'),
(15, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/2d0ff796-63fb-4728-9845-1334f57c73ea/mc-trainer-2-workout-shoes-WFVXbk.png'),
(15, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/18cd4f48-1577-4fd2-8039-136447710573/mc-trainer-2-workout-shoes-WFVXbk.png'),
(15, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/7f977177-646f-4bac-bb2a-ef66d7207c66/mc-trainer-2-workout-shoes-WFVXbk.png'),
(15, 'https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/bccd6891-fc9f-4929-949d-188c89faae84/mc-trainer-2-workout-shoes-WFVXbk.png');

CREATE TABLE PaymentMethod (
    PaymentMethodID INT PRIMARY KEY identity(1,1),
    PaymentName VARCHAR(100),
    CreatedAt DATETIME DEFAULT GETDATE()
);
go
-- Insert
INSERT INTO PaymentMethod (PaymentName)
VALUES 
('Cash'),
('Credit Card'),
('PayPal');


go
CREATE TABLE Shipping_Providers (
    ProviderID INT PRIMARY KEY identity(1,1),
    providerName NVARCHAR(255),
    Contact_Info NVARCHAR(255),
    createdAt DATE DEFAULT GETDATE(),
);
-- Insert
INSERT INTO Shipping_Providers (providerName, Contact_Info)
VALUES 
('FedEx', '1-800-463-3339, support@fedex.com'),
('UPS', '1-800-742-5877, support@ups.com'),
('DHL', '1-800-225-5345, support@dhl.com');

go
CREATE TABLE ShippingMethod (
    ShippingMethodID INT PRIMARY KEY identity (1,1),
    providerID INT,
    methodName NVARCHAR(255),
    estimated_delivery_time INT,
    cost DECIMAL(10, 2),
    FOREIGN KEY (providerID) REFERENCES Shipping_Providers(ProviderID)
);
go
-- Insert
INSERT INTO ShippingMethod (providerID, methodName, estimated_delivery_time, cost)
VALUES 
(1, 'Standard Shipping', 5, 10.00),
(2, 'Express Shipping', 2, 20.00),
(3, 'Rocket Shipping', 1, 30.00);

 
go
CREATE TABLE [Order] (
    OrderID INT PRIMARY KEY identity(1,1),
    UserID INT,
	fullName VARCHAR(50),
    phoneNumber VARCHAR(20),
    email VARCHAR(100),
    Street NVARCHAR(50),
	District NVARCHAR(50),
	City  NVARCHAR(50),
	PaymentMethodID int, 
	ShippingMethodID int,
	totalPrice DECIMAL(10, 2) default 0,
    createdAt DATE DEFAULT GETDATE(),
    order_status NVARCHAR(50) DEFAULT 'Waiting for accept',
    FOREIGN KEY (UserID) REFERENCES [User](UserID),
	FOREIGN KEY (PaymentMethodID) REFERENCES PaymentMethod(PaymentMethodID),
	FOREIGN KEY (ShippingMethodID) REFERENCES ShippingMethod(ShippingMethodID),
);
go


CREATE TABLE OrderDetail (
    OrderDetail_ID INT PRIMARY KEY identity(1,1),
    ProductID INT,
    OrderID INT,
    quantity INT,
    unitPrice DECIMAL(10, 2),
	afterSalePrice DECIMAL(10, 2),
    CreatedAt DATE default getdate(),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID), 
    FOREIGN KEY (OrderID) REFERENCES [Order](OrderID)
);
go
-- Insert 


CREATE TABLE Invoices (
    InvoicesID INT PRIMARY KEY identity(1,1),
	UserID int not null,
	OrderID int not null,
    fullName VARCHAR(50) not null,
    phoneNumber VARCHAR(20) not null,
    email VARCHAR(100) not null,
    Street NVARCHAR(50) not null,
	District NVARCHAR(50) not null,
	City  NVARCHAR(50) not null,
	PaymentName VARCHAR(100) not null, 
	ShipName NVARCHAR(255) not null,
	totalPrice DECIMAL(10, 2) not null ,
    createdAt DATE DEFAULT GETDATE(),
	FOREIGN KEY (UserID) REFERENCES [User](UserID),
	FOREIGN KEY (OrderID) REFERENCES [Order](OrderID)
);

go
CREATE TABLE Shipment (
    ShipmentID INT PRIMARY KEY identity (1,1),
    orderID INT,
    methodID INT,
    tracking_number NVARCHAR(255),
    shipped_date DATETIME,
    estimated_arrival DATETIME,
    Shipment_status NVARCHAR(50),
    FOREIGN KEY (orderID) REFERENCES [Order](OrderID),
    FOREIGN KEY (methodID) REFERENCES ShippingMethod(ShippingMethodID)
);
go
CREATE TABLE DiscountCode (
    discountid INT PRIMARY KEY identity(1,1),
    code NVARCHAR(255) not null,
    detail NVARCHAR(255),
    discountAmount DECIMAL(10, 2) default 0,
    startDay DATE default getdate(),
    endDay DATE default getdate(),
    usedLimit INT,
    discount_status BIT default 1
);

go
INSERT INTO DiscountCode (code, detail, discountAmount, usedLimit, discount_status)
VALUES 
('SUMMER2024', 'Summer discount', 50.00, 100, 1),
('WINTER2024', 'Winter discount', 100.00, 200, 0),
('NEWYEAR2025', 'New Year discount', 200.00, 50, 0),
('SPRING2024', 'Spring discount', 80.00,150, 0);

go
-- Create the UserPaymentMethod table
CREATE TABLE UserPaymentMethod (
    UserPaymentMethodID INT PRIMARY KEY identity(1,1),
    UserID INT,
    PaymentMethodID INT,
    CardNumber VARCHAR(20) not null,
    ExpiryDate DATE not null,
	CVC int not null,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES [User](userId),
    FOREIGN KEY (PaymentMethodID) REFERENCES PaymentMethod(PaymentMethodID)
);
go



-- Create the Payment table
CREATE TABLE Payment (
    PaymentID INT PRIMARY KEY identity (1,1),
    UserID INT,
    Method VARCHAR(100),
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES [User](userId),
);
go
-- Quan hệ n-n
go
-- Giảm giá

CREATE TABLE Order_Discount (
    Order_ID INT,
    Discount_ID INT,
	number_Use int default 1,
    PRIMARY KEY (Order_ID, Discount_ID),
    FOREIGN KEY (Order_ID) REFERENCES [Order](OrderID),
    FOREIGN KEY (Discount_ID) REFERENCES DiscountCode(discountid)
);
go